from abaqus import mdb, openMdb
from abaqusConstants import ANALYSIS, ODB, PERCENTAGE, SINGLE
import csv

CAE = r'C:\Thesis_Tower185\DTU\DTU158_HybridTower_v30_LT10K_MODAL.cae'
MODEL = 'DTU158_DLC13_U24_S06_INTERFACE_DYNAMIC'
AMP = 'AMP_SITE_U18p57_S04_FY_A_N'
CSV = r'C:\Thesis_Tower185\DTU\V30_LT10K_Analysis\DLC13_ETM_U24p00_S06_Abaqus_6DOF.csv'
JOB = 'DTU158_DLC13_U24_S06_INTERFACE_DYNAMIC_CTRL006'
WORK = r'C:\Thesis_Tower185\DTU\V30_LT10K_Analysis'
RNA_MASS_KG = 673998.0
G_M_S2 = 9.81

openMdb(pathName=CAE)
model = mdb.models[MODEL]
data = []
with open(CSV, 'r') as f:
    reader = csv.DictReader(f)
    time_key = reader.fieldnames[0]
    fy_key = [key for key in reader.fieldnames if key.endswith('FY_A_N')][0]
    for row in reader:
        data.append((float(row[time_key]), float(row[fy_key]) + RNA_MASS_KG * G_M_S2))
model.amplitudes[AMP].setValues(data=tuple(data))
if JOB in mdb.jobs:
    del mdb.jobs[JOB]
mdb.Job(name=JOB, model=MODEL, description='DLC1.3 U24 S06; OpenFAST FY corrected by removing RNA gravity already present in Abaqus gravity base state', type=ANALYSIS, memory=90, memoryUnits=PERCENTAGE, explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, resultsFormat=ODB, numCpus=4, numDomains=4)
mdb.save()
mdb.jobs[JOB].writeInput(consistencyChecking=0)
print('UPDATED_MODEL', MODEL)
print('UPDATED_AMPLITUDE', AMP)
print('FY_CORRECTION_N', RNA_MASS_KG * G_M_S2)
print('FY_FIRST_LAST_N', data[0][1], data[-1][1])
print('JOB', JOB)
