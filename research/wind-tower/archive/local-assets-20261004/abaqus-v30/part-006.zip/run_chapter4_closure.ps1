$ErrorActionPreference = 'Stop'

$work = 'C:\Thesis_Tower185\DTU\V30_LT10K_Analysis'
$abaqus = 'C:\SIMULIA\Commands\abq2025.bat'
$log = Join-Path $work 'chapter4_closure_runner.log'
$current = 'DTU158_RIKS_DLC13_S06_CDP_MODE1_A016'

Set-Location -LiteralPath $work
"$(Get-Date -Format s) waiting for $current" | Add-Content -LiteralPath $log

while (Test-Path -LiteralPath (Join-Path $work "$current.lck")) {
    Start-Sleep -Seconds 60
}

$currentSta = Join-Path $work "$current.sta"
if (-not (Test-Path -LiteralPath $currentSta) -or
    -not (Select-String -LiteralPath $currentSta -SimpleMatch 'THE ANALYSIS HAS COMPLETED SUCCESSFULLY' -Quiet)) {
    "$(Get-Date -Format s) $current did not complete successfully; sequence stopped" | Add-Content -LiteralPath $log
    exit 1
}

$jobs = @(
    'DTU158_RIKS_DLC13_S06_CDP_MODE1_A032',
    'DTU158_SITE_S04_INTERFACE_DYNAMIC_CTRL005',
    'DTU158_DLC13_U24_S06_INTERFACE_DYNAMIC_CTRL005'
)

foreach ($job in $jobs) {
    $inp = Join-Path $work "$job.inp"
    if (-not (Test-Path -LiteralPath $inp)) {
        "$(Get-Date -Format s) missing input: $inp" | Add-Content -LiteralPath $log
        exit 2
    }

    "$(Get-Date -Format s) starting $job" | Add-Content -LiteralPath $log
    & $abaqus "job=$job" "input=$inp" 'cpus=8' 'interactive' *>> $log

    $sta = Join-Path $work "$job.sta"
    if (-not (Test-Path -LiteralPath $sta) -or
        -not (Select-String -LiteralPath $sta -SimpleMatch 'THE ANALYSIS HAS COMPLETED SUCCESSFULLY' -Quiet)) {
        "$(Get-Date -Format s) $job failed; sequence stopped" | Add-Content -LiteralPath $log
        exit 3
    }
    "$(Get-Date -Format s) completed $job" | Add-Content -LiteralPath $log
}

"$(Get-Date -Format s) all Chapter 4 closure jobs completed" | Add-Content -LiteralPath $log
