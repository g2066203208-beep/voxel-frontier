# R7 TurbSim run status

36 formal `.inp` files were generated from the R7 task document. No `.bts` result is claimed until TurbSim completes and the binary header/QC is verified. Existing legacy `.bts` files were not copied because they use different geometry/time parameters.

Current gate: **BLOCKED — executable production incomplete**.
