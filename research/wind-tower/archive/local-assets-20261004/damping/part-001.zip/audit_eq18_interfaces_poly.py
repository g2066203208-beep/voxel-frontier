from pathlib import Path
import csv, numpy as np
ROOT=Path(r"C:\Users\tt\Documents\Codex\2026-08-30\turbsim"); BASE=ROOT/'outputs'/'damping_final_20260902_CORRECTED'
sh=list(csv.DictReader((BASE/'HISTORICAL_FORMAL_MODE_SHAPES_BY_ELEVATION.csv').open(encoding='utf-8-sig'))); ei=list(csv.DictReader((BASE/'HISTORICAL_FORMAL_EI_SEGMENTS.csv').open(encoding='utf-8-sig')))
segs={}
for r in ei: segs.setdefault(r['segment'],[]).append((float(r['global_elevation_m']),float(r['EI_Nm2'])))
for s in segs: segs[s].sort()
order=sorted(segs,key=lambda s:min(x[0] for x in segs[s]))
def fitseg(za,zb,z,y):
 idx=np.where((z>=za-4)&(z<=zb+4))[0]; idx=idx[np.argsort(abs(z[idx]-(za+zb)/2))[:min(len(idx),8)]]; xc=(za+zb)/2; sc=max(np.ptp(z[idx]),1.0); return np.polynomial.polynomial.polyfit((z[idx]-xc)/sc,y[idx],min(5,len(idx)-1)),xc,sc
rows=[]
for mode,field in [(1,'U1_norm'),(2,'U3_norm'),(3,'U1_norm'),(4,'U3_norm')]:
 rr=[r for r in sh if int(r['mode'])==mode]; z=np.array([float(r['elevation_m']) for r in rr]); y=np.array([float(r[field]) for r in rr]); o=np.argsort(z);z=z[o];y=y[o]; fits={}
 for s in order:
  za,zb=min(x[0] for x in segs[s]),max(x[0] for x in segs[s]); co,xc,sc=fitseg(za,zb,z,y); ec=np.polynomial.polynomial.polyfit(np.array([(q[0]-xc)/sc for q in segs[s]]),np.array([q[1] for q in segs[s]]),1); c2=np.polynomial.polynomial.polyder(co,2)/sc**2; c1=np.polynomial.polynomial.polyder(co,1)/sc; qc=np.polynomial.polynomial.polymul(ec,c2); fits[s]=(co,xc,sc,c1,qc)
 for a,b in zip(order[:-1],order[1:]):
  x=max(q[0] for q in segs[a]); ca,xa,sa,c1a,qca=fits[a]; cb,xb,sb,c1b,qcb=fits[b]; ta=(x-xa)/sa; tb=(x-xb)/sb; qa=np.polynomial.polynomial.polyval(ta,qca); qb=np.polynomial.polynomial.polyval(tb,qcb); va=np.polynomial.polynomial.polyval(ta,np.polynomial.polynomial.polyder(qca,1))/sa; vb=np.polynomial.polynomial.polyval(tb,np.polynomial.polynomial.polyder(qcb,1))/sb
  rows.append([mode,x,a,b,qa,qb,abs(qa-qb)/max(abs(qa),abs(qb),1e-30),va,vb,abs(va-vb)/max(abs(va),abs(vb),1e-30)])
out=BASE/'EQ18_INTERFACE_CONTINUITY_POLY.csv'
with out.open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f); w.writerow(['mode','interface_z_m','left_segment','right_segment','M_left_Nm','M_right_Nm','M_rel_jump','V_left_N','V_right_N','V_rel_jump']);w.writerows(rows)
print(out)
