# 正式阻尼输入准备状态（2026-09-02 修正版）

## 已完成

- 正式 ODB：`DTU158_V30_LT10K_GRAVITY_MODAL.odb`。
- 正式模态频率与身份：SS1=Mode 1（0.13513 Hz）、FA1=Mode 2（0.13568 Hz）、SS2=Mode 3（0.70700 Hz）、FA2=Mode 4（0.74218 Hz）。`FA_SS_MAPPING=PASS`。
- 从正式 ODB 提取了 4 个模态的 9888 个塔段节点位移，并汇总为 79 个高程层的归一化振型：[HISTORICAL_FORMAL_MODE_SHAPES_BY_ELEVATION.csv](HISTORICAL_FORMAL_MODE_SHAPES_BY_ELEVATION.csv)。
- 从正式 INP 的材料卡、节点几何和实例平移提取了 31 个混凝土段与 4 个钢段的变截面主体筒壁 EI：[HISTORICAL_FORMAL_EI_SEGMENTS.csv](HISTORICAL_FORMAL_EI_SEGMENTS.csv)。
- EI 表明确标记为“主体筒壁截面；未含钢筋/PT 等效增量”，没有将钢筋或 PT 偷含到主支路。普通纵向钢筋通过 `*Embedded Element` 嵌入各混凝土段；PT 为独立 T3D2 杆件并通过方程/锚固连接。预应力初始应力及几何刚度不重复计入材料 EI。

## 当前状态

- 普通钢筋/PT 的双支路已生成：`WALL_ONLY_EI` 与 `FORMAL_EFFECTIVE_EI`。
- `RNA_C2_RECONCILIATION=PASS`：权威冻结质量 676723.995578 kg；B31 重积分 676724.025091 kg；旧 673997.979913 kg 元数据已标记为 obsolete。
- Eq.(18) 已改为统一约束五阶重构的弱式，并使用完整 6×6 RNA 矩阵从 RA=(0,160,0) 运输到 TA=(0,158,0)。新的强/弱式恒等相对误差约 1e-16–1e-14。
- 当前结果仍是 `EQ18_FINAL=HOLD`：需要对正式 6×6 来源、界面边界项分区和重构/积分敏感性做最终独立审计；4.63–5.53% 仅为本轮诊断值。

在 Eq.(18) 数值闭合前，不写最终四个阻尼百分数；不修改 OpenFAST，不重跑 TurbSim/模态。
