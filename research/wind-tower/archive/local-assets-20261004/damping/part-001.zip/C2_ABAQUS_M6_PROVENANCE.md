# Formal RNA spatial mass matrix

The obsolete 673997.979913 kg SIMPACK metadata is excluded. The authoritative C2 mass/CG frozen values are m=676723.995578 kg and COM=(0,160.296599,-0.649270) m. The inertia tensor is the formal spatial-RNA B31 re-integration tensor in `FORMAL_RNA_MASS_PROPERTIES.csv` (about RA=(0,160,0)); the 6x6 matrix is transported to TA=(0,158,0) with M_TA=A^T M_RA A. This is a reproducible reconstruction pending no separate binary C2 matrix file.
