from pathlib import Path
import csv
BASE=Path(r"C:\Users\tt\Documents\Codex\2026-08-30\turbsim\outputs\damping_final_20260902_CORRECTED")
current={r['quantity']:float(r['value']) for r in csv.DictReader((BASE/'FORMAL_RNA_MASS_PROPERTIES.csv').open(encoding='utf-8-sig'))}
meta=next(r for r in csv.DictReader((Path(r'C:\Thesis_Tower185\DTU\SIMPACK_EXPORT\metadata\rna_component_mass_properties.csv')).open(encoding='utf-8-sig')) if r['component']=='RNA_TOTAL')
frozen={'mass_kg':float(meta['mass_kg']),'COM_y_m':float(meta['com_y_m']),'COM_z_m':float(meta['com_z_m'])}
target={'mass_kg':676723.9956,'COM_y_m':160.296599,'COM_z_m':-0.649270}
rows=[]
for key in ('mass_kg','COM_y_m','COM_z_m'):
    fv=frozen.get(key,float('nan')); tv=target.get(key,float('nan')); cv=current.get(key,float('nan'))
    rows.append([key,cv,fv,tv,cv-fv,cv-tv,(cv-tv)/tv if tv else float('nan')])
out=BASE/'RNA_C2_RECONCILIATION.csv'
with out.open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['quantity','INP_reconstruction','C2_metadata_found','C2_values_stated_by_user','INP_minus_metadata','INP_minus_user_target','relative_to_user_target']);w.writerows(rows)
(BASE/'RNA_C2_RECONCILIATION.md').write_text("""# RNA 6×6 reconciliation\n\nThe archived C2 metadata found on this workstation is `C:\\Thesis_Tower185\\DTU\\SIMPACK_EXPORT\\metadata\\rna_component_mass_properties.csv`. Its RNA_TOTAL row reports 673997.979913 kg, COM=(0,160.297798,-0.623190) m, and a full inertia tensor. The current direct INP line-mass reconstruction reports 676724.025091 kg, COM=(0,160.296598,-0.649270) m.\n\nThe user-stated frozen C2 target is m=676723.9956 kg, COM=(0,160.296599,-0.649270) m. Against that target, mass differs by approximately 0.0295 kg and COM agrees to about 1 micrometre in y; the z coordinate agrees to the shown precision. Against the archived metadata row, however, mass differs by about 2726 kg and COM-z by 0.0261 m. This is a provenance/version discrepancy, not a reason to silently overwrite either record. `RNA_6X6_FOR_EQ18` remains HOLD until the exact frozen C2 inertia file is identified or the user confirms the stated target as authoritative.\n""",encoding='utf-8')
print(out)
