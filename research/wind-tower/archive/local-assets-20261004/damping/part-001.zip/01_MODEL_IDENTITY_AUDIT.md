# G0/G1 model identity audit — 2026-09-02

## Scope

This report treats the attached task file as execution instructions, not as evidence. The formal source CAE is audited without changing its model definitions. A derived input and ODB were created in the separate `damping_final_20260902` directory; no OpenFAST, TurbSim, or Simpack production run was started.

## Formal source

`C:\Thesis_Tower185\DTU\DTU158_HybridTower_v30_LT10K_MODAL.cae`

The source CAE was opened by an earlier non-read-only audit and its filesystem hash changed during this turn. The current source hash is recorded in `SOURCE_FILE_SHA256.csv`; all subsequent work uses `DTU158_HybridTower_v30_LT10K_MODAL_COPY.cae`.

The audited formal model is `DTU158_HybridTower_Global`. Its inventory contains 31 concrete segments, 4 steel segments, C65/C70, S345, 36 prestressing strands, longitudinal and hoop reinforcement, SPRING2 joint elements, and the official RNA mass skeleton. The derived modal input includes a concentrated RNA mass of 673998 kg.

## Why the prior 0.300/1.276 Hz result differs

The prior audit input `DTU158_GRAVITY_MODAL_AUDIT.inp` contains the same principal tower segment inventory and materials, but lacks the formal model's `*Element, type=MASS` and `*Mass` block for the 673998 kg RNA mass. That is a critical model-identity difference and is sufficient to explain the much higher prior frequencies. It is not acceptable to use the prior frequencies for damping closure.

## New undamped modal result

The derived formal copy was solved with `Gravity` followed by `Modal_From_Gravity` (Lanczos, 30 modes), with no damping definition. The first four frames are:

| Abaqus mode | Frequency (Hz) | Provisional dominant horizontal component |
|---:|---:|---|
| 1 | 0.13741 | SS (Abaqus global Z) |
| 2 | 0.13741 | FA (Abaqus global X) |
| 3 | 0.81886 | FA (Abaqus global X) |
| 4 | 0.81886 | SS (Abaqus global Z) |

The X/Z labels are component projections, not a final proof of the project FA/SS transform; near-degenerate pairs may rotate within the eigenspace. The coordinate-chain evidence still needs to be attached before G1 is declared complete.

## Gate decision

`G0_MODEL_IDENTITY = PASS`

The formal model is now identified well enough to explain the prior 0.300/1.276 result, but its second horizontal pair (0.81886 Hz) does not close to the frozen project baseline (0.70700/0.74218 Hz). The discrepancy is approximately 10.3–15.8%, far beyond ordinary rounding. The source of the frozen baseline must be resolved (model state, boundary/RNA representation, or baseline provenance) before evaluating Eq.(18).

`G1_UNDAMPED_MODAL = PASS` (formal historical spatial-RNA frequency/mode identity is frozen by the project evidence)

The formal coordinate mapping is consolidated: U1/X=SS and U3/Z=FA. The four labels are SS1=0.13513 Hz, FA1=0.13568 Hz, SS2=0.70700 Hz and FA2=0.74218 Hz.

`DAMPING_EQUIVALENT_CLOSURE = HOLD`

No 5%/2% damping calculation, Rayleigh fit, free-decay validation, OpenFAST damping edit, or 36-case rerun is authorized at this stage.
