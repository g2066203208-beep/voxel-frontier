# Mode direction mapping (corrected, frozen transform)

The Abaqus model uses global Y as the vertical tower axis; the horizontal plane is X–Z. The project transform is `+X_OpenFAST (downwind) -> +Z_Abaqus` and `+Y_OpenFAST (lateral) -> +X_Abaqus`. Therefore Abaqus U1/X is OpenFAST SS and Abaqus U3/Z is OpenFAST FA.

| Abaqus mode | Frequency (Hz) | Abaqus dominant direction | OpenFAST identity |
|---:|---:|---|---|
| 1 | 0.13513 | U1 / X | SS1 |
| 2 | 0.13568 | U3 / Z | FA1 |
| 3 | 0.70700 | U1 / X | SS2 |
| 4 | 0.74218 | U3 / Z | FA2 |

The numerical Eq.(18) values are unchanged and remain provisional pending segment-wise differentiation and grid-convergence.
