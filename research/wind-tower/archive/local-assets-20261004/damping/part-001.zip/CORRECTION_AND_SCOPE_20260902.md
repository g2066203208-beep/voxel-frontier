# Damping audit correction (2026-09-02)

## Frozen coordinate transform

`+X_OF (downwind) -> +Z_A`; `+Y_OF (lateral) -> +X_A`. Therefore Abaqus U1/X is OpenFAST SS and Abaqus U3/Z is OpenFAST FA.

| Abaqus mode | f (Hz) | OpenFAST label |
|---:|---:|---|
| 1 | 0.13513 | SS1 |
| 2 | 0.13568 | FA1 |
| 3 | 0.70700 | SS2 |
| 4 | 0.74218 | FA2 |

The corrected Eq.(18) CSV only relabels the existing provisional WALL_ONLY_EI values; no ODB or modal result was recomputed. Final Eq.(18) remains open pending segment-wise differentiation and grid-convergence.

## EI branches

`WALL_ONLY_EI` is the Li et al. (2024) baseline. `FORMAL_EFFECTIVE_EI` must be computed separately after auditing embedded longitudinal reinforcement and the actual PT constraints. Initial PT stress/geometric stiffness must not be double-counted as material EI.

Reference: Li Shouzhen et al. (2024), Journal of Southeast University (Natural Science Edition), 54(1), 9-16, DOI 10.3969/j.issn.1001-0505.2024.01.002.

## Gate status

`G0_MODEL_IDENTITY=PASS`; `FA_SS_MAPPING=PASS`; `EQ18_FINAL=HOLD`; `RAYLEIGH=NOT_STARTED`; `DTU158_DAMPING_CLOSURE=HOLD`.
