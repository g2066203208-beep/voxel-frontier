import csv, math
from pathlib import Path
import numpy as np

ROOT=Path(r"C:\Users\tt\Documents\Codex\2026-08-30\turbsim")
BASE=ROOT/'outputs'/'damping_final_20260902_CORRECTED'
sh=list(csv.DictReader((BASE/'HISTORICAL_FORMAL_MODE_SHAPES_BY_ELEVATION.csv').open(encoding='utf-8-sig')))
ei=list(csv.DictReader((BASE/'HISTORICAL_FORMAL_EI_SEGMENTS.csv').open(encoding='utf-8-sig')))
segs={}
for r in ei: segs.setdefault(r['segment'],[]).append((float(r['global_elevation_m']),float(r['EI_Nm2'])))
for s in segs: segs[s].sort()
order=sorted(segs,key=lambda s:min(x[0] for x in segs[s]))
def deriv(x,xp,fp,d):
 idx=np.argsort(abs(xp-x))[:min(len(xp),7)]; xs=xp[idx]; fs=fp[idx]; sc=max(np.ptp(xs),1.0); t=(xs-x)/sc; deg=min(5,len(idx)-1); c=np.polynomial.polynomial.polyfit(t,fs,deg); return np.polynomial.polynomial.polyval(0,np.polynomial.polynomial.polyder(c,d))/sc**d
rows=[]
for mode,field in [(1,'U1_norm'),(2,'U3_norm'),(3,'U1_norm'),(4,'U3_norm')]:
 rr=[r for r in sh if int(r['mode'])==mode]; z=np.array([float(r['elevation_m']) for r in rr]); y=np.array([float(r[field]) for r in rr]); o=np.argsort(z); z=z[o]; y=y[o]
 for a,b in zip(order[:-1],order[1:]):
  zi=max(x[0] for x in segs[a] if x[0]<=min(x[0] for x in segs[b])+1e-4)
  def side(s,side):
   za=min(x[0] for x in segs[s]); zb=max(x[0] for x in segs[s]); xg=np.linspace(za,zb,25); ee=np.interp(xg,*zip(*segs[s])); cur=np.array([deriv(x,z,y,2) for x in xg]); q=ee*cur; x=zb if side=='L' else za; return x, deriv(x,z,y,2), deriv(xg[-1] if side=='L' else xg[0],xg,q,0), deriv(xg[-1] if side=='L' else xg[0],xg,q,1)
  try:
   za,ca,qa,sa=side(a,'L'); zb,cb,qb,sb=side(b,'R');
   rows.append([mode,zi,a,b,qa,qb,abs(qa-qb)/max(abs(qa),abs(qb),1e-30),sa,sb,abs(sa-sb)/max(abs(sa),abs(sb),1e-30)])
  except Exception: pass
out=BASE/'EQ18_INTERFACE_CONTINUITY.csv'
with out.open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f); w.writerow(['mode','interface_z_m','left_segment','right_segment','M_left_Nm','M_right_Nm','M_rel_jump','V_left_N','V_right_N','V_rel_jump']); w.writerows(rows)
print(out)
