# Global Rayleigh parameter fit

Eq.(19) is used: zeta_j=alpha/(2 omega_j)+beta omega_j/2. A single global pair is fitted exactly to the arithmetic means of the SS/FA first-horizontal and second-horizontal frequency/damping pairs. The four individual residuals are reported, not hidden. These coefficients are ready for a free-decay validation input; they have not yet been applied to any production model.
