# Eq.(18) segment-wise closure status

The corrected FA/SS labels are SS1=Mode 1, FA1=Mode 2, SS2=Mode 3, FA2=Mode 4. The calculation was repeated at 1.82, 2, 1, 0.5 and 0.25 m evaluation grids. Within each of the 31 concrete and 4 steel structural segments, curvature and the second derivative of `EI*y''` were evaluated without differencing across the 112 m material interface.

Two branches are reported: `WALL_ONLY_EI` and `FORMAL_EFFECTIVE_EI`. The latter adds the elastic contribution of the embedded longitudinal bars parsed from the formal INP. The 36 PT tendons are independent T3D2 members with top equation/anchor constraints; their initial stress/geometric stiffness is not double-counted as material EI.

The prior independent-segment fourth-derivative grid table is retained as historical diagnostic only. The active method is the unified constrained weak form in `EQ18_CONSTRAINED_RECONSTRUCTION_RESULTS.csv`, with complete M6 RNA top inertia. Strong/weak identity is now numerically closed on the same constrained reconstruction (relative error <1e-14). `EQ18_FINAL` remains `HOLD` pending final independent review of reconstruction and EI-branch sensitivity; no Rayleigh/OpenFAST edit is allowed while this gate is HOLD.
