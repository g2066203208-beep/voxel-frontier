# 模型身份追溯结论（2026-09-02）

## 结论

`0.81886 Hz` 与历史正式 `0.70700/0.74218 Hz` 的差异已定位为 RNA 表示方式不同，不是应通过调整 EI、质量或阻尼去追频率的数值误差。

## 证据

历史正式输入/ODB：

`C:\Thesis_Tower185\DTU\V30_LT10K_Analysis\DTU158_V30_LT10K_GRAVITY_MODAL.inp/.odb`

- 含 `*Part, name=RNA_MASS_SKELETON_OFFICIAL`；
- 含 32 个 RNA 骨架节点、28 个梁单元；
- 含 `MAT_RNA_BLD_Z1..Z5`、`MAT_RNA_HUB_EQ`、`MAT_RNA_NAC_EQ` 分区密度；
- 含 `RB_RNA_DISTRIBUTED_OFFICIAL`，将空间 RNA 骨架作为刚体连接到 `SET_RNA_RP`；
- 不含集中 `*Element, type=MASS` / `*Mass` 块；
- 模态频率：0.13513、0.13568、0.70700、0.74218 Hz。

当前派生副本输入/ODB：

`C:\Users\tt\Documents\Codex\2026-08-30\turbsim\outputs\damping_final_20260902\DTU158_HYBRID_UNDAMPED_MODAL_20260902.inp/.odb`

- 没有 `RNA_MASS_SKELETON_OFFICIAL` 部件/实例；
- 用单个 `*Element, type=MASS` + `*Mass` 在 `SET_RNA_RP` 施加 `673998 kg` 集中质量；
- 塔段、钢段、PT、SPRING2、基础边界及 `COUPLING_RNA_TOP` 保留；
- 模态频率：0.13741、0.13741、0.81886、0.81886 Hz。

## 判定

集中质量与空间 RNA 即使总质量相同，也不会保持相同的质量分布、质心偏置和转动惯量；因此高阶/第二水平模态出现 0.81886 Hz 是该建模替换的结果。历史正式模型应作为阻尼计算的正式模型候选，当前副本只能作为对照审计，不能用于正式式(18)。

本结论不证明历史模型的参数绝对正确，但已证明两组频率不是同一模型的可直接比较结果。后续式(18)必须使用历史正式 ODB 对应的空间 RNA 模型，并先完成正式模态方向/MAC及 `EI(x)` 提取。

`G0_MODEL_IDENTITY`: CLOSED_FOR_FORMAL_CANDIDATE（历史正式空间 RNA 模型）  
`CURRENT_COPY_FOR_PRODUCTION`: NO  
`DAMPING_EQ18`: PREPARATION_STARTED；尚未写入最终数值

## 下一步门禁

正式式(18)计算将只使用历史正式空间 RNA ODB 的 Mode 1–4、塔段材料/截面刚度和混凝土/钢段分界。由于第一、二阶为近简并水平模态，FA/SS 方向需由项目坐标变换和模态子空间投影最终确认；在该确认及 `EI(x)` 提取完成前，不发布最终阻尼百分数。
