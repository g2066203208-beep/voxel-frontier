"""Weak-form Eq.(18) evaluation using smooth mode reconstruction and explicit RNA tip inertia.
This is an audit diagnostic: it does not claim closure unless strong/weak identities agree.
"""
from pathlib import Path
import csv, math, re
import numpy as np

ROOT=Path(r"C:\Users\tt\Documents\Codex\2026-08-30\turbsim")
BASE=ROOT/'outputs'/'damping_final_20260902_CORRECTED'
INP=Path(r"C:\Thesis_Tower185\DTU\V30_LT10K_Analysis\DTU158_V30_LT10K_GRAVITY_MODAL.inp")

def parse_rna(inp):
    L=inp.read_text(encoding='utf-8',errors='ignore').splitlines(); i=next(i for i,l in enumerate(L) if l.lower().startswith('*part, name=rna_mass_skeleton_official')); j=next(i for i in range(i+1,len(L)) if L[i].lower().startswith('*end part'))
    nodes={}; elems={}; sets={}; sections={}; active=False
    k=i
    while k<j:
        l=L[k].strip()
        if l.lower()=='*node':
            k+=1
            while k<j and not L[k].startswith('*'):
                q=[x.strip() for x in L[k].split(',')]
                if len(q)>=4:
                    try:nodes[int(q[0])]=np.array([float(q[1]),float(q[2]),float(q[3])])
                    except:pass
                k+=1
            continue
        m=re.match(r'\*element,\s*type=([^,]+)',l,re.I)
        if m:
            k+=1
            while k<j and not L[k].startswith('*'):
                q=[x.strip() for x in L[k].split(',')]
                if len(q)>=3:
                    try: elems[int(q[0])]=[int(x) for x in q[1:]]
                    except:pass
                k+=1
            continue
        m=re.match(r'\*elset,\s*elset=([^,]+)(.*)',l,re.I)
        if m:
            name=m.group(1); gen='generate' in m.group(2).lower(); k+=1; vals=[]
            while k<j and not L[k].startswith('*'):
                q=[x.strip() for x in L[k].split(',') if x.strip()]
                try:
                    nums=[int(float(x)) for x in q]
                    if gen and len(nums)>=3: vals.extend(range(nums[0],nums[1]+1,nums[2]))
                    else: vals.extend(nums)
                except:pass
                k+=1
            sets[name]=set(vals); continue
        m=re.match(r'\*beam section,\s*elset=([^,]+),\s*material=([^,\s]+)',l,re.I)
        if m:
            name,mat=m.group(1),m.group(2); sections[name]=mat
        k+=1
    # material densities from global material cards
    rho={}
    for k,l in enumerate(L):
        m=re.match(r'\*material,\s*name=([^,\s]+)',l,re.I)
        if m:
            for q in L[k+1:k+8]:
                if q.lower().startswith('*density'):
                    try: rho[m.group(1)]=float(L[L.index(q,k+1)].split(',')[0])
                    except: pass
                    break
    # safer density scan by local index
    for k,l in enumerate(L):
        m=re.match(r'\*material,\s*name=([^,\s]+)',l,re.I)
        if m:
            for z in range(k+1,min(k+10,len(L))):
                if L[z].lower().startswith('*density') and z+1<len(L):
                    try: rho[m.group(1)]=float(L[z+1].split(',')[0])
                    except: pass
                    break
    area=math.pi*0.01**2
    pts=[]; elem_info=[]
    for eid,conn in elems.items():
        if len(conn)<2: continue
        p0,p1=nodes[conn[0]],nodes[conn[1]]; Lm=float(np.linalg.norm(p1-p0))
        mat=''; elset=''
        for s,ids in sets.items():
            if eid in ids and s in sections: elset=s; mat=sections[s]; break
        if not mat: continue
        mass=rho.get(mat,float('nan'))*area*Lm
        # 2-point midpoint quadrature for first/second moments about RP=(0,160,0)
        for t,w in [(0.2113248654,0.5),(0.7886751346,0.5)]: pts.append((p0*(1-t)+p1*t,mass*w))
        elem_info.append([eid,elset,mat,Lm,mass])
    rp=np.array([0.,160.,0.]); M=sum(w for _,w in pts); com=sum((p*w for p,w in pts),np.zeros(3))/M
    I=np.zeros((3,3))
    for p,w in pts:
        r=p-rp; I+=w*((r@r)*np.eye(3)-np.outer(r,r))
    out=BASE/'FORMAL_RNA_MASS_PROPERTIES.csv'
    with out.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.writer(f); w.writerow(['quantity','value']); w.writerow(['mass_kg',M]); w.writerow(['COM_x_m',com[0]]); w.writerow(['COM_y_m',com[1]]); w.writerow(['COM_z_m',com[2]]); w.writerow(['Ixx_kgm2',I[0,0]]); w.writerow(['Iyy_kgm2',I[1,1]]); w.writerow(['Izz_kgm2',I[2,2]]); w.writerow(['Ixy_kgm2',I[0,1]]); w.writerow(['Ixz_kgm2',I[0,2]]); w.writerow(['Iyz_kgm2',I[1,2]])
    with (BASE/'FORMAL_RNA_ELEMENT_MASS_AUDIT.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.writer(f);w.writerow(['element','elset','material','length_m','mass_kg']);w.writerows(elem_info)
    return M,com,I

M,com,I=parse_rna(INP)
rp=np.array([0.,160.,0.])
sh=list(csv.DictReader((BASE/'HISTORICAL_FORMAL_MODE_SHAPES_BY_ELEVATION.csv').open(encoding='utf-8-sig')))
ei=list(csv.DictReader((BASE/'HISTORICAL_FORMAL_EI_SEGMENTS.csv').open(encoding='utf-8-sig')))
segs={}
for r in ei: segs.setdefault(r['segment'],[]).append((float(r['global_elevation_m']),float(r['EI_Nm2'])))
for s in segs: segs[s].sort()
order=sorted(segs,key=lambda s:min(x[0] for x in segs[s]))
def dpoly(x,xp,fp,d,deg=5):
 idx=np.argsort(abs(xp-x))[:min(len(xp),deg+2)]; xs=xp[idx]; fs=fp[idx]; sc=max(np.ptp(xs),1.0); t=(xs-x)/sc; c=np.polynomial.polynomial.polyfit(t,fs,min(deg,len(idx)-1)); return float(np.polynomial.polynomial.polyval(0,np.polynomial.polynomial.polyder(c,d))/sc**d)
freq={1:.13513,2:.13568,3:.707,4:.74218}; labels={1:'SS1',2:'FA1',3:'SS2',4:'FA2'}; fields={1:'U1_norm',2:'U3_norm',3:'U1_norm',4:'U3_norm'}
rna=list(csv.DictReader((BASE/'FORMAL_RNA_INTERFACE_MODAL.csv').open(encoding='utf-8-sig')))
results=[]
for mode in range(1,5):
 rr=[r for r in sh if int(r['mode'])==mode]; z=np.array([float(r['elevation_m']) for r in rr]); y=np.array([float(r[fields[mode]]) for r in rr]); o=np.argsort(z); z=z[o]; y=y[o]
 qrp=next(r for r in rna if int(r['mode'])==mode); u=float(qrp['U1_norm'] if mode in (1,3) else qrp['U3_norm']); p=float(qrp['UR3_norm'] if mode in (1,3) else qrp['UR1_norm'])
 # weak bulk integral + tip RNA inertia boundary term. Cross first moment uses COM offset from RP.
 for branch in ('WALL_ONLY_EI','FORMAL_EFFECTIVE_EI'):
  Dc=Ds=0.;
  for s in order:
   za,zb=min(x[0] for x in segs[s]),max(x[0] for x in segs[s]); zg=np.linspace(za,zb,max(16,int((zb-za)/0.25)+1)); ew=np.interp(zg,*zip(*segs[s]));
   inc=0.
   if branch=='FORMAL_EFFECTIVE_EI' and s.startswith('CSEG_'):
    inc=float(next(r for r in csv.DictReader((BASE/'FORMAL_EFFECTIVE_EI_SEGMENTS.csv').open(encoding='utf-8-sig')) if r['segment']==s)['rebar_EI_increment_Nm2'])
   cur=np.array([dpoly(x,z,y,2) for x in zg]); val=float(np.trapezoid((ew+inc)*cur**2,zg));
   if zb<=112: Dc+=val
   elif za>=112: Ds+=val
   else:
    cut=zg<112; Dc+=float(np.trapezoid(((ew+inc)*cur**2)[cut],zg[cut])); Ds+=float(np.trapezoid(((ew+inc)*cur**2)[~cut],zg[~cut]))
  # Use tip q=[u,theta] in the bending plane. theta=-p for SS (rotation about Z), theta=p for FA.
  omega=2*math.pi*freq[mode];
  if mode in (1,3):
   ry=com[1]-rp[1]; mtt=np.array([[M, M*ry],[M*ry,I[2,2]]]); q=np.array([u,-p])
  else:
   rx=com[0]-rp[0]; mtt=np.array([[M, -M*rx],[-M*rx,I[0,0]]]); q=np.array([u,p])
  tip=float(omega**2*(q@mtt@q)); Dc_tip=Dc; Ds_tip=Ds+tip
  zeta=(0.05*Dc_tip+0.02*Ds_tip)/(Dc_tip+Ds_tip) if (Dc_tip+Ds_tip)>0 else float('nan')
  results.append([mode,labels[mode],freq[mode],branch,Dc_tip,Ds_tip,tip,zeta,'weak bulk + explicit RNA inertia; PT geometric stiffness excluded'])
with (BASE/'EQ18_WEAK_FORM_RESULTS.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['mode','openfast_label','frequency_hz','EI_branch','D_concrete_bulk','D_steel_plus_RNA','D_RNA_tip_boundary','eq18_weak_zeta','method']);w.writerows(results)
(BASE/'EQ18_WEAK_FORM_SCOPE_20260902.md').write_text("""# R7_DAMPING_EQ18_WEAK_FORM_CLOSURE\n\nThis stage replaces fourth-order finite differences with the integration-by-parts weak form of Li et al. (2024): bulk `∫EI(y'')²dx` plus boundary work `[yV-y'M]`. The calculation uses the 79-layer historical ODB shape reconstruction only through y, y' and y''. The formal spatial RNA skeleton was parsed from the INP to obtain mass, COM and inertia; the top boundary term is evaluated from the modal RNA interface generalized coordinates and `ω² M_RNA`. PT is not added as material EI.\n\n`EQ18_WEAK_FORM_RESULTS.csv` reports WALL_ONLY_EI and FORMAL_EFFECTIVE_EI. This is not automatically PASS: the strong/weak identity, interface traction continuity, and sensitivity to the shape reconstruction must be compared before Rayleigh damping.\n""",encoding='utf-8')
print('RNA mass',M,'COM',com,'Ixx/Izz',I[0,0],I[2,2])
