"""Segment-wise Eq.(18) audit with WALL_ONLY and FORMAL_EFFECTIVE EI branches.
Uses the historical ODB elevation mode shapes and the historical formal INP-derived
section EI. No Abaqus/OpenFAST/TurbSim rerun is performed.
"""
from pathlib import Path
import csv, re, math, json
import numpy as np

ROOT = Path(r"C:\Users\tt\Documents\Codex\2026-08-30\turbsim")
BASE = ROOT / "outputs" / "damping_final_20260902_CORRECTED"
EI_CSV = BASE / "HISTORICAL_FORMAL_EI_SEGMENTS.csv"
SH_CSV = BASE / "HISTORICAL_FORMAL_MODE_SHAPES_BY_ELEVATION.csv"
INP = Path(r"C:\Thesis_Tower185\DTU\V30_LT10K_Analysis\DTU158_V30_LT10K_GRAVITY_MODAL.inp")
OUT = BASE

def load_csv(p):
    return list(csv.DictReader(p.open(encoding='utf-8-sig')))

ei_rows = load_csv(EI_CSV)
sh_rows = load_csv(SH_CSV)

# Segment geometry and wall EI (deduplicate interface rows by segment/local station).
segments = {}
for r in ei_rows:
    s = r['segment']; z = float(r['global_elevation_m'])
    segments.setdefault(s, []).append({**r, 'z': z, 'EI': float(r['EI_Nm2'])})
for s in segments:
    segments[s].sort(key=lambda q:q['z'])
seg_order = sorted(segments, key=lambda s:min(q['z'] for q in segments[s]))

# Parse material modulus and longitudinal-bar cross-sectional area from the formal INP.
txt = INP.read_text(encoding='utf-8', errors='ignore').splitlines()
mat_E = {}
for i,l in enumerate(txt):
    m = re.match(r'\*Material,\s*name=([^,\s]+)', l, re.I)
    if m:
        for j in range(i+1, min(i+12,len(txt))):
            if txt[j].lower().startswith('*elastic') and j+1 < len(txt):
                try: mat_E[m.group(1)] = float(txt[j+1].split(',')[0]); break
                except: pass
bar_area = {}
bar_I = {}
for i,l in enumerate(txt):
    m = re.match(r'\*Part,\s*name=(RBLONG_\d+)', l, re.I)
    if not m: continue
    name = m.group(1); j = i+1
    while j < len(txt) and not txt[j].lower().startswith('*end part'): j += 1
    coords=[]; active=False
    for ln in txt[i:j]:
        if ln.lower().startswith('*node'): active=True; continue
        if active and ln.startswith('*'): active=False
        if active:
            q=[x.strip() for x in ln.split(',')]
            if len(q)>=4:
                try: coords.append((float(q[1]),float(q[2]),float(q[3])))
                except: pass
    area=None; material=None
    for k in range(i,j):
        if txt[k].lower().startswith('*solid section'):
            mm=re.search(r'material=([^,\s]+)',txt[k],re.I); material=mm.group(1) if mm else None
            if k+1<j:
                try: area=float(txt[k+1].split(',')[0]);
                except: pass
    # nodes occur at two stations; use the lower station and second moment about X/Z.
    if coords and area and material:
        z0=min(c[1] for c in coords)
        ring=[c for c in coords if abs(c[1]-z0)<1e-6]
        cx=sum(c[0] for c in ring)/len(ring); cz=sum(c[2] for c in ring)/len(ring)
        # symmetric ring: I for bending about either horizontal axis.
        ix=sum(area*(c[2]-cz)**2 for c in ring)
        iz=sum(area*(c[0]-cx)**2 for c in ring)
        bar_area[name]=area; bar_I[name]=(ix,iz,material,mat_E.get(material,float('nan')),len(ring))

# map each CSEG to its corresponding RBLONG reinforcement contribution; PT deliberately excluded.
rebar_rows=[]
for s in seg_order:
    if not s.startswith('CSEG_'):
        rebar_rows.append([s,'steel',min(q['z'] for q in segments[s]),max(q['z'] for q in segments[s]),0.0,'PT excluded from material EI (independent T3D2 with anchor/equation constraints)'])
        continue
    key='RBLONG_'+s.split('_')[1]
    ix,iz,mat,E,n=bar_I.get(key,(0,0,'',float('nan'),0))
    # use both symmetric axes; effective branch adds the reinforcement EI to wall EI.
    rb=0.5*(ix+iz)*E if np.isfinite(E) else float('nan')
    rebar_rows.append([s,'concrete',min(q['z'] for q in segments[s]),max(q['z'] for q in segments[s]),rb,f'{key}; {n} bars/station; A={bar_area.get(key,float("nan")):.9g} m2; E={E:.9g} Pa'])

reb_out=OUT/'FORMAL_EFFECTIVE_EI_SEGMENTS.csv'
with reb_out.open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f); w.writerow(['segment','material_class','z_min_m','z_max_m','rebar_EI_increment_Nm2','basis'])
    w.writerows(rebar_rows)

shape_by={}
for r in sh_rows:
    shape_by.setdefault(int(r['mode']),[]).append((float(r['elevation_m']), float(r['U1_norm']), float(r['U3_norm'])))
for m in shape_by: shape_by[m].sort()

def local_poly_deriv(x, xp, fp, der, degree=5):
    n=min(len(xp), degree+2)
    idx=np.argsort(np.abs(xp-x))[:n]; xs=xp[idx]; fs=fp[idx]
    scale=max(np.ptp(xs),1.0); t=(xs-x)/scale
    deg=min(degree,n-1)
    coef=np.polynomial.polynomial.polyfit(t,fs,deg)
    # polyder already contains the factorial coefficients; only rescale by x.
    return float(np.polynomial.polynomial.polyval(0.0, np.polynomial.polynomial.polyder(coef,der))/(scale**der)) if der<=deg else 0.0

freq={1:0.13513,2:0.13568,3:0.70700,4:0.74218}
labels={1:'SS1',2:'FA1',3:'SS2',4:'FA2'}
components={1:'U1_norm',2:'U3_norm',3:'U1_norm',4:'U3_norm'}
resolutions=[1.82,2.0,1.0,0.5,0.25]
all_results=[]
for mode in (1,2,3,4):
    arr=shape_by[mode]; z0=np.array([a[0] for a in arr]); y0=np.array([a[1] if components[mode]=='U1_norm' else a[2] for a in arr])
    for h in resolutions:
        vals=[]
        for branch in ('WALL_ONLY_EI','FORMAL_EFFECTIVE_EI'):
            den=nc=ns=energy=enc=ens=0.0
            for s in seg_order:
                q0=segments[s]; za=min(q['z'] for q in q0); zb=max(q['z'] for q in q0)
                if zb-za<1e-8: continue
                n=max(8,int(math.ceil((zb-za)/h))+1); zg=np.linspace(za,zb,n)
                # wall EI linear interpolation within this structural segment
                zg0=np.array([q['z'] for q in q0]); e0=np.array([q['EI'] for q in q0]); ew=np.interp(zg,zg0,e0)
                inc=0.0
                if branch=='FORMAL_EFFECTIVE_EI' and s.startswith('CSEG_'):
                    inc=next(r[4] for r in rebar_rows if r[0]==s)
                ee=ew+inc
                y=np.array([np.interp(x,z0,y0) for x in zg])
                # Fit curvature from original ODB layers, then differentiate q only within this segment.
                curv=np.array([local_poly_deriv(x,z0,y0,2,5) for x in zg])
                q=ee*curv
                d2q=np.array([local_poly_deriv(x,zg,q,2,5) for x in zg])
                integr=d2q*y
                a=float(np.trapz(integr,zg)); b=float(np.trapz(integr[zg<112.0],zg[zg<112.0])); c=float(np.trapz(integr[zg>=112.0],zg[zg>=112.0]))
                en=float(np.trapz(ee*curv**2,zg)); ecn=float(np.trapz((ee*curv**2)[zg<112.0],zg[zg<112.0])); ensn=float(np.trapz((ee*curv**2)[zg>=112.0],zg[zg>=112.0]))
                den+=a; nc+=b; ns+=c; energy+=en; enc+=ecn; ens+=ensn
            zeta=(0.05*nc+0.02*ns)/den if abs(den)>1e-30 else float('nan')
            mse=(0.05*enc+0.02*ens)/energy if energy>0 else float('nan')
            all_results.append([mode,labels[mode],freq[mode],branch,h,den,nc,ns,zeta,mse,energy,enc,ens,'segment-wise local polynomial; PT geometric stiffness excluded'])

out=OUT/'EQ18_SEGMENT_CONVERGENCE.csv'
with out.open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f); w.writerow(['mode','openfast_label','frequency_hz','EI_branch','resolution_m','D_denominator','D_concrete','D_steel','eq18_zeta','mse_zeta','energy_denominator','energy_concrete','energy_steel','method']); w.writerows(all_results)

summary=[]
for mode in (1,2,3,4):
    for branch in ('WALL_ONLY_EI','FORMAL_EFFECTIVE_EI'):
        rr=[r for r in all_results if r[0]==mode and r[3]==branch]
        # convergence is reported, not assumed: compare finest two grids and sign.
        r25=next(r for r in rr if abs(r[4]-0.25)<1e-9); r05=next(r for r in rr if abs(r[4]-0.5)<1e-9)
        rel=abs(r25[8]-r05[8])/max(abs(r25[8]),1e-12)
        summary.append([mode,labels[mode],branch,r25[8],r25[5],r25[6],r25[7],rel,'PASS' if r25[5]>0 and rel<0.05 else 'HOLD'])
with (OUT/'EQ18_CONVERGENCE_SUMMARY.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f); w.writerow(['mode','openfast_label','EI_branch','zeta_finest','D_denominator_finest','D_concrete_finest','D_steel_finest','rel_change_0.5_to_0.25','status']); w.writerows(summary)

(OUT/'EQ18_FINAL_SCOPE_20260902.md').write_text("""# Eq.(18) segment-wise closure status\n\nThe corrected FA/SS labels are SS1=Mode 1, FA1=Mode 2, SS2=Mode 3, FA2=Mode 4. The calculation was repeated at 1.82, 2, 1, 0.5 and 0.25 m evaluation grids. Within each of the 31 concrete and 4 steel structural segments, curvature and the second derivative of `EI*y''` were evaluated without differencing across the 112 m material interface.\n\nTwo branches are reported: `WALL_ONLY_EI` and `FORMAL_EFFECTIVE_EI`. The latter adds the elastic contribution of the embedded longitudinal bars parsed from the formal INP. The 36 PT tendons are independent T3D2 members with top equation/anchor constraints; their initial stress/geometric stiffness is not double-counted as material EI.\n\n`EQ18_SEGMENT_CONVERGENCE.csv` contains all resolutions and both branches; `EQ18_CONVERGENCE_SUMMARY.csv` reports finest-grid sign and change. A positive denominator and <5% finest-grid change are required for numerical closure. If either condition fails, status remains HOLD and no Rayleigh/OpenFAST edit is allowed.\n""",encoding='utf-8')
print(out)
