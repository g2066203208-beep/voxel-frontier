from pathlib import Path
import csv, numpy as np
BASE=Path(r"C:\Users\tt\Documents\Codex\2026-08-30\turbsim\outputs\damping_final_20260902_CORRECTED")
fit=list(csv.DictReader((BASE/'EQ18_CONSTRAINED_MODE_SHAPES.csv').open(encoding='utf-8-sig')))
odb=list(csv.DictReader((BASE/'HISTORICAL_FORMAL_MODE_SHAPES_BY_ELEVATION.csv').open(encoding='utf-8-sig')))
rows=[]
for mode,field in [(1,'U1_norm'),(2,'U3_norm'),(3,'U1_norm'),(4,'U3_norm')]:
 for branch in ('WALL_ONLY_EI','FORMAL_EFFECTIVE_EI'):
  ff=[r for r in fit if int(r['mode'])==mode and r['EI_branch']==branch]; oo=[r for r in odb if int(r['mode'])==mode]; pred=[]; obs=[]
  for r in oo:
   z=float(r['elevation_m']); q=min(ff,key=lambda x:abs(float(x['elevation_m'])-z)); pred.append(float(q['y'])); obs.append(float(r[field]))
  e=np.asarray(pred)-np.asarray(obs); rows.append([mode,branch,float(np.sqrt(np.mean(e*e))),float(np.max(np.abs(e))),len(ff)])
out=BASE/'EQ18_CONSTRAINED_RECONSTRUCTION_RESIDUALS.csv'
with out.open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['mode','EI_branch','ODB_fit_RMS','ODB_fit_max_abs','fit_points']);w.writerows(rows)
print(out)
