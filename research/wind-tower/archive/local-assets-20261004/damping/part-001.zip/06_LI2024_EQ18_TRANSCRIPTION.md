# Li et al. (2024) Eq.(18) transcription record

Source: Li Shouzhen et al., *Dynamic response analysis of steel-concrete hybrid tower considering P-Δ effect*, Journal of Southeast University (Natural Science Edition), 54(1), 2024, pp. 9–16, DOI 10.3969/j.issn.1001-0505.2024.01.002. The PDF page 4 was visually checked.

The paper's Eq.(18) is used as the sole primary equivalent-damping equation. In notation matching the printed equation:

ξ_e,j = [ ξ_c,j ∫_0^(h1+h2) {d²/dx²[K(x) d²y_j/dx²]} y_j(x) dx
          + ξ_s,j ∫_(h1+h2)^H {d²/dx²[K(x) d²y_j/dx²]} y_j(x) dx ]
         / ∫_0^H {d²/dx²[K(x) d²y_j/dx²]} y_j(x) dx.

Here y_j(x) is the j-th mode shape, K(x) is the sectional bending stiffness, H is total tower height, h1 is the concrete segment height and h2 is the transition height. ξ_c,j and ξ_s,j are the concrete and steel base damping ratios. The paper states ξ_c=0.05 and ξ_s=0.02 for its engineering example; this project labels them LI2024_REFERENCE_BASE_DAMPING and does not treat them as measured 158 m prototype truth.

Implementation rule: the code must evaluate the printed differential operator and segment integrals; it must not replace Eq.(18) by height, mass, or simple EI weighting. Rayleigh Eq.(19) is a separate conversion/check and is not written into the production model in the current gate.

Status: transcription complete; numerical Eq.(18) evaluation is intentionally blocked until G0/G1 model identity and mode-frequency provenance are closed.
