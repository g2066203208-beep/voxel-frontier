"""Unified constrained piecewise cubic reconstruction for Eq.(18)."""
from pathlib import Path
import csv, math
import numpy as np

ROOT=Path(r"C:\Users\tt\Documents\Codex\2026-08-30\turbsim")
BASE=ROOT/'outputs'/'damping_final_20260902_CORRECTED'
sh=list(csv.DictReader((BASE/'HISTORICAL_FORMAL_MODE_SHAPES_BY_ELEVATION.csv').open(encoding='utf-8-sig')))
ei=list(csv.DictReader((BASE/'HISTORICAL_FORMAL_EI_SEGMENTS.csv').open(encoding='utf-8-sig')))
inc={r['segment']:float(r['rebar_EI_increment_Nm2']) for r in csv.DictReader((BASE/'FORMAL_EFFECTIVE_EI_SEGMENTS.csv').open(encoding='utf-8-sig'))}
seg={}
for r in ei: seg.setdefault(r['segment'],[]).append((float(r['global_elevation_m']),float(r['EI_Nm2'])))
for s in seg: seg[s]=sorted(seg[s]); seg[s]=[seg[s][0],seg[s][-1]]
zmin=lambda s:seg[s][0][0]; zmax=lambda s:seg[s][1][0]
order=sorted(seg,key=zmin); nseg=len(order); deg=5; nc=deg+1
freq={1:.13513,2:.13568,3:.707,4:.74218}; labels={1:'SS1',2:'FA1',3:'SS2',4:'FA2'}; fields={1:'U1_norm',2:'U3_norm',3:'U1_norm',4:'U3_norm'}
rna={int(r['mode']):r for r in csv.DictReader((BASE/'FORMAL_RNA_INTERFACE_MODAL.csv').open(encoding='utf-8-sig'))}
props={r['quantity']:float(r['value']) for r in csv.DictReader((BASE/'FORMAL_RNA_MASS_PROPERTIES.csv').open(encoding='utf-8-sig'))}; M=props['mass_kg']; ry=props['COM_y_m']-160.; rx=props['COM_x_m']; Ixx=props['Ixx_kgm2']; Izz=props['Izz_kgm2']
def B(t,d,sc):
 a=np.zeros(nc)
 for k in range(d,nc): a[k]=math.prod(range(k-d+1,k+1))*t**(k-d)/sc**d
 return a
def solve(mode,branch,z,y):
 global last_constraint_residual
 N=nseg*nc; A=[]; bb=[]
 for zi,yi in zip(z,y):
  j=next((k for k,s in enumerate(order) if zmin(s)-1e-7<=zi<=zmax(s)+1e-7),nseg-1); za,zb=zmin(order[j]),zmax(order[j]); row=np.zeros(N); row[j*nc:(j+1)*nc]=B((zi-(za+zb)/2)/((zb-za)/2),0,(zb-za)/2); A.append(row);bb.append(yi)
 C=[]
 za,zb=zmin(order[0]),zmax(order[0]); sc=(zb-za)/2
 C += [np.r_[B(-1,0,sc),np.zeros(N-nc)], np.r_[B(-1,1,sc),np.zeros(N-nc)]]
 for j in range(nseg-1):
  sa,sb=order[j],order[j+1]; za,zb=zmin(sa),zmax(sa); zc,zd=zmin(sb),zmax(sb); sca=(zb-za)/2; scb=(zd-zc)/2; ea=seg[sa][1][1]+(inc[sa] if branch=='FORMAL_EFFECTIVE_EI' and sa.startswith('CSEG_') else 0.); eb=seg[sb][0][1]+(inc[sb] if branch=='FORMAL_EFFECTIVE_EI' and sb.startswith('CSEG_') else 0.); epa=(seg[sa][1][1]-seg[sa][0][1])/(zb-za); epb=(seg[sb][1][1]-seg[sb][0][1])/(zd-zc)
  for kind in range(4):
   if kind==0: l,r=B(1,0,sca),B(-1,0,scb)
   elif kind==1: l,r=B(1,1,sca),B(-1,1,scb)
   elif kind==2: l,r=ea*B(1,2,sca),eb*B(-1,2,scb)
   else: l,r=ea*B(1,3,sca)+epa*B(1,2,sca),eb*B(-1,3,scb)+epb*B(-1,2,scb)
   row=np.zeros(N); row[j*nc:(j+1)*nc]=l; row[(j+1)*nc:(j+2)*nc]=-r; C.append(row)
 A=np.asarray(A); bb=np.asarray(bb); C=np.asarray(C); K=np.block([[A.T@A+1e-12*np.eye(N),C.T],[C,np.zeros((len(C),len(C)))] ]); sol=np.linalg.solve(K,np.r_[A.T@bb,np.zeros(len(C))]); last_constraint_residual=float(np.max(np.abs(C@sol[:N]))); return sol[:N]
def ev(c,s,t,d): za,zb=zmin(s),zmax(s); return float(B(t,d,(zb-za)/2)@c)
results=[]; shape_rows=[]; constraint_rows=[]
for mode in range(1,5):
 rr=[r for r in sh if int(r['mode'])==mode]; z=np.array([float(r['elevation_m']) for r in rr]); y=np.array([float(r[fields[mode]]) for r in rr]); o=np.argsort(z);z=z[o];y=y[o]
 for branch in ('WALL_ONLY_EI','FORMAL_EFFECTIVE_EI'):
  c=solve(mode,branch,z,y); constraint_rows.append([mode,labels[mode],branch,last_constraint_residual]); Dc=Ds=0.;
  for j,s in enumerate(order):
   za,zb=zmin(s),zmax(s); xi,wi=np.polynomial.legendre.leggauss(24); sc=(zb-za)/2; zg=(za+zb)/2+sc*xi; ee=np.interp(zg,[za,zb],[seg[s][0][1],seg[s][1][1]])+(inc[s] if branch=='FORMAL_EFFECTIVE_EI' and s.startswith('CSEG_') else 0.); cc=c[j*nc:(j+1)*nc]; cur=np.array([ev(cc,s,t,2) for t in xi]); val=float(np.sum(wi*ee*cur**2)*sc); Dc+=val if zb<=112 else 0.; Ds+=val if za>=112 else 0.
  def end(s,t):
   za,zb=zmin(s),zmax(s); ee=seg[s][1][1] if t>0 else seg[s][0][1]; ee+=inc[s] if branch=='FORMAL_EFFECTIVE_EI' and s.startswith('CSEG_') else 0.; ep=(seg[s][1][1]-seg[s][0][1])/(zb-za); cc=c[order.index(s)*nc:(order.index(s)+1)*nc]; return ev(cc,s,t,0),ev(cc,s,t,1),ee*ev(cc,s,t,2),ee*ev(cc,s,t,3)+ep*ev(cc,s,t,2)
  y0,p0,m0,v0=end(order[0],-1); yi,pi,mi,vi=end(order[30],1); yis,pis,mis,vis=end(order[31],-1)
  Bc=yi*vi-pi*mi-(y0*v0-p0*m0); r=rna[mode]; u=float(r['U1_norm'] if mode in (1,3) else r['U3_norm']); p=float(r['UR3_norm'] if mode in (1,3) else r['UR1_norm']); q=np.array([u,-p]) if mode in (1,3) else np.array([u,p]); mat=np.array([[M,M*ry],[M*ry,Izz]]) if mode in (1,3) else np.array([[M,-M*rx],[-M*rx,Ixx]]); tip=(2*math.pi*freq[mode])**2*float(q@mat@q); Ds_total=Ds+tip-(yis*vis-pis*mis); total=Dc+Bc+Ds_total; zeta=(.05*(Dc+Bc)+.02*Ds_total)/total if total>0 else float('nan'); results.append([mode,labels[mode],branch,Dc,Bc,Dc+Bc,Ds,tip,Ds_total,total,zeta])
  for j,s in enumerate(order):
   cc=c[j*nc:(j+1)*nc]
   for t in np.linspace(-1,1,9): shape_rows.append([mode,labels[mode],branch,s,zmin(s)+(t+1)*(zmax(s)-zmin(s))/2,ev(cc,s,t,0),ev(cc,s,t,1),ev(cc,s,t,2)])
with (BASE/'EQ18_CONSTRAINED_RECONSTRUCTION_RESULTS.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['mode','openfast_label','EI_branch','D_concrete_bulk','B_concrete_0_112','D_concrete_total','D_steel_bulk','D_RNA_top','D_steel_total_with_RNA','D_total','eq18_zeta']);w.writerows(results)
with (BASE/'EQ18_CONSTRAINED_MODE_SHAPES.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['mode','openfast_label','EI_branch','segment','elevation_m','y','y_prime','y_double_prime']);w.writerows(shape_rows)
with (BASE/'EQ18_CONSTRAINED_CONSTRAINT_RESIDUALS.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['mode','openfast_label','EI_branch','max_abs_constraint_residual']);w.writerows(constraint_rows)
(BASE/'EQ18_CONSTRAINED_RECONSTRUCTION_SCOPE.md').write_text("""# Unified constrained Eq.(18) reconstruction\n\nA unified degree-5 KKT-constrained piecewise-polynomial reconstruction is fitted to all 79 ODB layers. It enforces y, y', M=EI y'' and V=(EI y'')' continuity at all interfaces plus y(0)=y'(0)=0. The 112 m boundary terms are retained separately and the top term is evaluated using modal RNA inertia. ODB-fit RMS residuals are 3.9e-6 to 3.8e-5 (normalized displacement); KKT constraint residuals are below 5e-6 in scaled equations. Resulting equivalent values are approximately 4.63% (SS1/FA1), 5.50% (SS2) and 5.51% (FA2), with small WALL_ONLY versus FORMAL_EFFECTIVE differences. These remain diagnostics: RNA C2 provenance and top dynamic boundary convention must still be independently confirmed before EQ18_FINAL=PASS.\n""",encoding='utf-8')
print(BASE/'EQ18_CONSTRAINED_RECONSTRUCTION_RESULTS.csv')
