from pathlib import Path
import csv, numpy as np, math
ROOT=Path(r"C:\Users\tt\Documents\Codex\2026-08-30\turbsim"); BASE=ROOT/'outputs'/'damping_final_20260902_CORRECTED'
sh=list(csv.DictReader((BASE/'HISTORICAL_FORMAL_MODE_SHAPES_BY_ELEVATION.csv').open(encoding='utf-8-sig'))); ei=list(csv.DictReader((BASE/'HISTORICAL_FORMAL_EI_SEGMENTS.csv').open(encoding='utf-8-sig')))
segs={}
for r in ei: segs.setdefault(r['segment'],[]).append((float(r['global_elevation_m']),float(r['EI_Nm2'])))
for s in segs: segs[s].sort()
order=sorted(segs,key=lambda s:min(x[0] for x in segs[s])); inc={r['segment']:float(r['rebar_EI_increment_Nm2']) for r in csv.DictReader((BASE/'FORMAL_EFFECTIVE_EI_SEGMENTS.csv').open(encoding='utf-8-sig'))}
freq={1:.13513,2:.13568,3:.707,4:.74218}; labels={1:'SS1',2:'FA1',3:'SS2',4:'FA2'}; fields={1:'U1_norm',2:'U3_norm',3:'U1_norm',4:'U3_norm'}
rna={int(r['mode']):r for r in csv.DictReader((BASE/'FORMAL_RNA_INTERFACE_MODAL.csv').open(encoding='utf-8-sig'))}
props={r['quantity']:float(r['value']) for r in csv.DictReader((BASE/'FORMAL_RNA_MASS_PROPERTIES.csv').open(encoding='utf-8-sig'))}; M=props['mass_kg']; ry=props['COM_y_m']-160; rx=props['COM_x_m']; Ixx=props['Ixx_kgm2']; Izz=props['Izz_kgm2'];
rows=[]
for mode in range(1,5):
 rr=[r for r in sh if int(r['mode'])==mode]; z=np.array([float(r['elevation_m']) for r in rr]); y=np.array([float(r[fields[mode]]) for r in rr]); o=np.argsort(z);z=z[o];y=y[o]; domains=[(0,112),(112,158)]; fits={}
 for da,db in domains:
  idx=np.where((z>=da-3)&(z<=db+3))[0]; xc=(da+db)/2; sc=(db-da)/2; t=(z[idx]-xc)/sc; co=np.polynomial.polynomial.polyfit(t,y[idx],min(9,len(idx)-1)); fits[(da,db)]=(co,xc,sc)
 for branch in ('WALL_ONLY_EI','FORMAL_EFFECTIVE_EI'):
  bulk=[0.,0.]; boundary=[0.,0.]; strong=[0.,0.]
  for s in order:
   za,zb=min(x[0] for x in segs[s]),max(x[0] for x in segs[s]); dom=(0,112) if zb<=112 else (112,158); co,xc,sc=fits[dom]; zg=np.linspace(za,zb,40); tt=(zg-xc)/sc; c1=np.polynomial.polynomial.polyder(co,1)/sc; c2=np.polynomial.polynomial.polyder(co,2)/sc**2; yy=np.polynomial.polynomial.polyval(tt,co); yp=np.polynomial.polynomial.polyval(tt,c1); cur=np.polynomial.polynomial.polyval(tt,c2); ew=np.interp(zg,*zip(*segs[s])); ee=ew+(inc[s] if branch=='FORMAL_EFFECTIVE_EI' and s.startswith('CSEG_') else 0); ec=np.polynomial.polynomial.polyfit(tt,ee,1); qc=np.polynomial.polynomial.polymul(ec,c2); q=np.polynomial.polynomial.polyval(tt,qc); qp=np.polynomial.polynomial.polyval(tt,np.polynomial.polynomial.polyder(qc,1))/sc; qpp=np.polynomial.polynomial.polyval(tt,np.polynomial.polynomial.polyder(qc,2))/sc**2; k=0 if dom==(0,112) else 1; bulk[k]+=float(np.trapezoid(ee*cur**2,zg)); strong[k]+=float(np.trapezoid(yy*qpp,zg)); boundary[k]+=float(yy[-1]*qp[-1]-yp[-1]*q[-1]-yy[0]*qp[0]+yp[0]*q[0])
  r=rna[mode]; u=float(r['U1_norm'] if mode in (1,3) else r['U3_norm']); p=float(r['UR3_norm'] if mode in (1,3) else r['UR1_norm']); q=np.array([u,-p]) if mode in (1,3) else np.array([u,p]); mat=np.array([[M,M*ry],[M*ry,Izz]]) if mode in (1,3) else np.array([[M,-M*rx],[-M*rx,Ixx]]); tip=(2*math.pi*freq[mode])**2*float(q@mat@q); den=(bulk[0]+bulk[1]+boundary[0]+boundary[1]-boundary[0] + tip) # retain only external top boundary via RNA; internal residual listed separately
  # external-domain weak denominator: bulk + internal interface residual + RNA top
  total=bulk[0]+bulk[1]+(boundary[0]+boundary[1])+tip; zeta=(.05*(bulk[0]+boundary[0])+.02*(bulk[1]+boundary[1]+tip))/total if total>0 else float('nan')
  rows.append([mode,labels[mode],branch,bulk[0],bulk[1],boundary[0],boundary[1],tip,total,zeta,strong[0]+strong[1],bulk[0]+bulk[1]+boundary[0]+boundary[1]])
with (BASE/'EQ18_GLOBAL_WEAK_DIAGNOSTIC.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['mode','openfast_label','EI_branch','bulk_concrete','bulk_steel','boundary_concrete_domain','boundary_steel_domain','top_RNA_boundary','total_weak_denominator','zeta_with_boundary_terms','strong_integral_domain','weak_integral_domain']);w.writerows(rows)
print(BASE/'EQ18_GLOBAL_WEAK_DIAGNOSTIC.csv')
