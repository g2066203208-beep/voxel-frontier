import csv, struct
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent
CH=['RotSpeed','BldPitch1','BldPitch2','BldPitch3','RotThrust','GenTq','GenPwr','LSShftTq','HSShftTq']

def read(p):
    with p.open('rb') as f:
        fid,nl,nc,nt=struct.unpack('<hhii',f.read(12)); t0,dt=struct.unpack('<2d',f.read(16)); sl=np.frombuffer(f.read(4*nc),dtype='<f4').astype(float); of=np.frombuffer(f.read(4*nc),dtype='<f4').astype(float); dl=struct.unpack('<i',f.read(4))[0]; f.read(dl); names=[f.read(nl).decode('ascii','ignore').strip() for _ in range(nc+1)]; units=[f.read(nl).decode('ascii','ignore').strip() for _ in range(nc+1)]; x=np.frombuffer(f.read(nt*nc*2),dtype='<i2')
    return names,units,t0+dt*np.arange(nt),((x.reshape(nt,nc).astype(float)-of)/sl),dt

def st(x):
    return {'mean':float(np.mean(x)),'std':float(np.std(x,ddof=1)),'min':float(np.min(x)),'max':float(np.max(x)),'rms':float(np.sqrt(np.mean(x*x))),'p95':float(np.percentile(x,95)),'p99':float(np.percentile(x,99))}

def main():
    rows=[]
    for d in sorted((ROOT/'CASES').iterdir()):
        if not d.is_dir() or not d.name.startswith('U'): continue
        p=d/'DTU_10MW_RWT.outb'
        if not p.exists(): continue
        names,units,t,x,dt=read(p); ix={n:i for i,n in enumerate(names)}; mask=(t>=100)&(t<=700)
        for c in CH:
            if c not in ix: continue
            rows.append({'case_id':d.name,'channel':c,'unit':units[ix[c]],'dt_s':dt,'n_samples':int(mask.sum()),**st(x[mask,ix[c]])})
    with (ROOT/'FORMAL_36CASE_CONTROL_CHANNEL_METRICS.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print(f'control rows={len(rows)} cases={len(set(r["case_id"] for r in rows))}')
if __name__=='__main__': main()
