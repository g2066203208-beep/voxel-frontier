import csv, hashlib, json, re, shutil, subprocess, time
from datetime import datetime
from pathlib import Path

ROOT = Path(r"C:\Users\tt\Documents\Codex\2026-08-30\openfast\CH3_CDX06_R1_36CASE")
SRC_CASES = ROOT / "CASES"
BTS = Path(r"C:\Users\tt\Documents\Codex\2026-08-29\new-chat\outputs\CH3_CDX05_R7_TURBSIM_FINAL_36CASE\inputs")
EXE = ROOT / "TEMPLATE_FROZEN" / "openfast_x64_v353.exe"
OUT = Path(__file__).resolve().parent
CASE_OUT = OUT / "CASES"
NEW_DAMP = {"TwrFADmp(1)":4.6350, "TwrFADmp(2)":5.5344, "TwrSSDmp(1)":4.6341, "TwrSSDmp(2)":5.5282}
LABEL_RE = re.compile(r'^\s*[-+0-9.Ee]+\s+(Twr(?:FA|SS)Dmp\([12]\))(?=\s|$)')
SKIP = {'.out','.outb','.sum','.ech','.dbg','.fstchkp','.fstf'}

def sha256(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''): h.update(b)
    return h.hexdigest()
def case_ids():
    return [f'{u}_{w}_S{s:02d}' for u in ('U09p343881','U11p4','U19p202140') for w in ('NTM','ETM') for s in range(1,7)]
def copy_tree(src,dst):
    for p in src.rglob('*'):
        q=dst/p.relative_to(src)
        if p.is_dir(): q.mkdir(parents=True,exist_ok=True)
        elif p.suffix.lower() not in SKIP: q.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,q)
def prepare(cid):
    src=SRC_CASES/cid; dst=CASE_OUT/cid; dst.mkdir(parents=True,exist_ok=True)
    copy_tree(src,dst)
    iw=dst/'DTU_10MW_InflowWind.dat'; txt=iw.read_text(encoding='utf-8',errors='replace'); bts_line='"'+str(BTS/(cid+'.bts'))+'" FileName_BTS'
    txt=re.sub(r'(?m)^\s*"[^"]+\.bts"\s+FileName_BTS',lambda _m:bts_line,txt); iw.write_text(txt,encoding='ascii',errors='replace')
    tw=dst/'C02R3R2_158M_Tower.dat'; lines=tw.read_text(encoding='utf-8',errors='replace').splitlines(); out=[]; seen=[]
    for line in lines:
        m=LABEL_RE.match(line)
        if m:
            label=m.group(1); seen.append(label); out.append(f'        {NEW_DAMP[label]:.4f}   {label} - formal objectified damping; Li Shou-zhen (2024)');
        else: out.append(line)
    tw.write_text('\n'.join(out)+'\n',encoding='ascii')
    return dst,seen
def read_damping(p):
    vals={}
    for line in p.read_text(encoding='ascii',errors='replace').splitlines():
        m=LABEL_RE.match(line)
        if m: vals[m.group(1)]=float(line.split()[0])
    return vals
def preflight(cids):
    rows=[]; ok=True
    for cid in cids:
        d=CASE_OUT/cid; p=d/'C02R3R2_158M_Tower.dat'; vals=read_damping(p); good=all(k in vals and abs(vals[k]-v)<1e-9 for k,v in NEW_DAMP.items()) and len(vals)==4
        rows.append({'case_id':cid,'TwrFADmp1_actual':vals.get('TwrFADmp(1)'), 'TwrFADmp2_actual':vals.get('TwrFADmp(2)'), 'TwrSSDmp1_actual':vals.get('TwrSSDmp(1)'), 'TwrSSDmp2_actual':vals.get('TwrSSDmp(2)'), 'tower_file_sha256':sha256(p), 'status':'PASS' if good else 'FAIL'}); ok &= good
    with (OUT/'FORMAL_36CASE_ACTUAL_DAMPING.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    shutil.copy2(OUT/'FORMAL_36CASE_ACTUAL_DAMPING.csv', OUT/'R2_DAMPING_PREFLIGHT.csv')
    (OUT/'R2_DAMPING_PREFLIGHT_STATUS.txt').write_text('PASS\n' if ok else 'FAIL\n',encoding='ascii')
    if not ok: raise RuntimeError('Damping preflight failed; no OpenFAST job submitted')

def read_outb(path):
    with path.open('rb') as f:
        fid,nlen,nchan,nt=__import__('struct').unpack('<hhii',f.read(12)); t0,dt=__import__('struct').unpack('<2d',f.read(16))
        slope=__import__('numpy').frombuffer(f.read(4*nchan),dtype='<f4').astype(float); off=__import__('numpy').frombuffer(f.read(4*nchan),dtype='<f4').astype(float)
        dlen=__import__('struct').unpack('<i',f.read(4))[0]; f.read(dlen)
        names=[f.read(nlen).decode('ascii','ignore').strip() for _ in range(nchan+1)]; units=[f.read(nlen).decode('ascii','ignore').strip() for _ in range(nchan+1)]
        packed=__import__('numpy').frombuffer(f.read(nt*nchan*2),dtype='<i2')
    data=(packed.reshape(nt,nchan).astype(float)-off)/slope; return names,t0+dt*__import__('numpy').arange(nt),data,dt

def pilot_crosscheck():
    import numpy as np
    prev=OUT.parent/'openfast_damping_regression_20260903'
    channels=['YawBrTDxp','YawBrTDyp','YawBrTAxp','YawBrTAyp','TwrBsMxt','TwrBsMyt']; metrics=['std','rms','min','max']; rows=[]; ok=True
    def vals(p):
        names,t,data,dt=read_outb(p); ix={n:i for i,n in enumerate(names)}; mask=(t>=100)&(t<=700); out={}
        for ch in channels:
            x=data[mask,ix[ch]]; out[ch]={m:float({'std':np.std(x,ddof=1),'rms':np.sqrt(np.mean(x*x)),'min':x.min(),'max':x.max()}[m]) for m in metrics}
        return out
    for wind in ['NTM','ETM']:
        cid=f'U11p4_{wind}_S01'; actual=vals(CASE_OUT/cid/'DTU_10MW_RWT.outb'); ref=vals(prev/f'{cid}_new'/'DTU_10MW_RWT.outb')
        for ch in channels:
            for m in metrics:
                a=actual[ch][m]; b=ref[ch][m]; diff=a-b; tol=1e-7+1e-6*abs(b); good=abs(diff)<=tol; ok &= good
                rows.append({'case_id':cid,'channel':ch,'metric':m,'r2_value':a,'reference_new_value':b,'difference':diff,'tolerance':tol,'status':'PASS' if good else 'FAIL'})
    with (OUT/'R2_PILOT_CROSSCHECK.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (OUT/'R2_PILOT_CROSSCHECK_STATUS.txt').write_text('PASS\n' if ok else 'FAIL\n',encoding='ascii')
    if not ok: raise RuntimeError('Pilot crosscheck failed; full 36-case queue not submitted')
def run_case(cid, status):
    d=CASE_OUT/cid; log=d/'openfast_stdout.log'; outb=d/'DTU_10MW_RWT.outb'
    if outb.exists(): outb.unlink()
    r={'case_id':cid,'start_time':'','end_time':'','wall_time_s':'','return_code':'','final_sim_time':'','rosco_loaded':'','has_nan_inf':'','outb_exists':'','status':'RUNNING','failure_reason':''}; status[cid]=r; save_status(status)
    st=datetime.now().astimezone(); r['start_time']=st.isoformat(); save_status(status); t=time.time()
    with log.open('w',encoding='utf-8',errors='replace') as lf: rc=subprocess.run([str(EXE),'DTU_10MW_RWT.fst'],cwd=d,stdout=lf,stderr=subprocess.STDOUT).returncode
    txt=log.read_text(encoding='utf-8',errors='replace'); en=datetime.now().astimezone(); r['end_time']=en.isoformat(); r['wall_time_s']=f'{time.time()-t:.1f}'; r['return_code']=str(rc); r['outb_exists']='YES' if outb.exists() else 'NO'; r['final_sim_time']='700' if re.search(r'Time:\s*700\s+of\s+700',txt) else ''; r['rosco_loaded']='YES' if 'Running ROSCO-v2.6.0' in txt else 'NO'; r['has_nan_inf']='YES' if re.search(r'\b(?:NaN|Inf|Infinity)\b',txt,re.I) else 'NO'; good=rc==0 and r['final_sim_time']=='700' and r['rosco_loaded']=='YES' and r['has_nan_inf']=='NO' and outb.exists(); r['status']='PASS' if good else 'FAIL'; r['failure_reason']='' if good else 'see openfast_stdout.log'; save_status(status); print(cid,r['status'],flush=True); return good
def save_status(status):
    ids=case_ids(); fields=['case_id','start_time','end_time','wall_time_s','return_code','final_sim_time','rosco_loaded','has_nan_inf','outb_exists','status','failure_reason']
    with (OUT/'R2_FORMAL_36CASE_STATUS.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();
        for cid in ids: w.writerow(status.get(cid,{'case_id':cid,'status':'PENDING'}))
def main():
    OUT.mkdir(parents=True,exist_ok=True); CASE_OUT.mkdir(parents=True,exist_ok=True)
    shared=CASE_OUT/'Rotor'
    if not shared.exists(): copy_tree(SRC_CASES/'U11p4_NTM_S01'/'Rotor',shared)
    cids=case_ids();
    for cid in cids: prepare(cid)
    preflight(cids)
    status={}; save_status(status)
    pilots=['U11p4_NTM_S01','U11p4_ETM_S01']
    for cid in pilots:
        if not run_case(cid,status): raise RuntimeError('Pilot failed; full queue stopped')
    pilot_crosscheck()
    (OUT/'R2_PILOT_PRECHECK_PASS.txt').write_text('NTM_S01 and ETM_S01 PASS\n',encoding='ascii')
    for cid in cids:
        if cid not in pilots:
            if not run_case(cid,status): print('FAILED CASE; queue continues for audit',flush=True)
    (OUT/'R2_FORMAL_36CASE_RUN_COMPLETE.txt').write_text('complete\n',encoding='ascii')
if __name__=='__main__': main()
