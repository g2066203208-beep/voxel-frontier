# OpenFAST Formal Objectified Damping 36-case R2

All 36 cases completed with actual tower damping values verified before submission. The two U11.4 S01 pilot cases passed cross-check against the validated new-damping regression.

Damping (%): FA1=4.6350, FA2=5.5344, SS1=4.6341, SS2=5.5282.

Original TurbSim BTS files were reused; TurbSim was not rerun. Each case reached 700 s, ROSCO loaded, and no NaN/Inf markers were found.

Use the CSV metrics, group summary, and control ranking for reporting. DEL/rainflow is NOT_RUN; old-damping DEL must not be reused.
