# Rainflow + Load-DEL 正式审计门禁

生成时间：2026-09-05T11:06:06

输入为已完成的正式对象化阻尼 36 个 OpenFAST `.outb`；本轮不重跑 OpenFAST，也不重跑 TurbSim。

| Gate | Status |
|---|---|
| `FORMAL_36CASE_INPUT_MATRIX` | **PASS** |
| `FORMAL_DAMPING_ACTUAL_READBACK` | **PASS** |
| `OUTB_700S_DT0.05_AUDIT` | **PASS** |
| `CHANNEL_INDEX_CORRECTION_QA` | **PASS** |
| `RAINFLOW_CYCLE_LEDGER` | **PASS** |
| `DEL_M4_ALL36` | **PASS** |
| `DEL_GROUPS_3X2X2` | **PASS** |
| `GOODMAN_CORRECTION` | **NOT APPLIED** |
| `TURBSIM_RERUN` | **NOT APPLIED** |
| `OPENFAST_RERUN` | **NOT APPLIED** |

## 固定口径

- 统计窗口：100–700 s（600 s）；输出步长：0.05 s。
- Rainflow：ASTM E1049-85(2017) 风格 stack 计数；循环记录含 range、amplitude、mean、count（0.5/1.0）。
- 正式载荷通道：`TwrBsMxt`、`TwrBsMyt`。
- 载荷 DEL：钢塔比较口径 `m=4`，`Neq=100000`；未做 Goodman 均值修正。
- 该 DEL 是载荷比较指标，不是混凝土/钢材疲劳寿命；材料寿命需另行采用 S–N、Miner 和材料应力。

