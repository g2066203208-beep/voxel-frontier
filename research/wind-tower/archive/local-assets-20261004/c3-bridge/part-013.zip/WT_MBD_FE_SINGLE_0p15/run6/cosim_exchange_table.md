# Simpack–Abaqus exchange table

- Report: `C:\Users\tt\Documents\Codex\simpack-mcp-runs\C3_SIMPACK_ABAQUS_INTERFACE_CLOSURE_20260906\WT_MBD_FE_SINGLE_0p15\run6\persistent_cosim_report.json`
- Status: `FAILED`
- Records: `1`

| sequence | request_time_s | macro_start_s | macro_end_s | simpack_to_abaqus_FX | simpack_to_abaqus_FY | simpack_to_abaqus_FZ | simpack_to_abaqus_MX | simpack_to_abaqus_MY | simpack_to_abaqus_MZ | tower_top_pos_ux | tower_top_pos_uy | tower_top_pos_uz | tower_top_pos_rx | tower_top_pos_ry | tower_top_pos_rz | simpack_returncode | simpack_wall_s | coupling_write_status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.0 | 0.0 | 0.05 | 55198.71875 | 22757.18359375 | 1.6159631965884103e-10 | -7.328446183230142e-11 | -2.8512628369448123e-10 | 241044.578125 |  |  |  |  |  |  | 0 | 2.4366893999977037 |  |
