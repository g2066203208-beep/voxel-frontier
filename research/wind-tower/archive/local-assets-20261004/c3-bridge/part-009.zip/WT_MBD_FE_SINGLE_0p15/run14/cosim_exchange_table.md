# Simpack–Abaqus exchange table

- Report: `C:\Users\tt\Documents\Codex\simpack-mcp-runs\C3_SIMPACK_ABAQUS_INTERFACE_CLOSURE_20260906\WT_MBD_FE_SINGLE_0p15\run14\persistent_cosim_report.json`
- Status: `COMPLETED`
- Records: `3`

| sequence | request_time_s | macro_start_s | macro_end_s | simpack_to_abaqus_FX | simpack_to_abaqus_FY | simpack_to_abaqus_FZ | simpack_to_abaqus_MX | simpack_to_abaqus_MY | simpack_to_abaqus_MZ | tower_top_pos_ux | tower_top_pos_uy | tower_top_pos_uz | tower_top_pos_rx | tower_top_pos_ry | tower_top_pos_rz | simpack_returncode | simpack_wall_s | coupling_write_status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.0 | 0.0 | 0.05 | 55198.71875 | 22757.18359375 | 1.6159631965884103e-10 | -7.328446183230142e-11 | -2.8512628369448123e-10 | 241044.578125 |  |  |  |  |  |  | 0 | 2.450168599956669 |  |
| 2 | 0.04999999999999993 | 0.05 | 0.1 | 49868.34765625 | 20467.31640625 | 2.0306770154299159e-10 | -2.2930289611533539e-10 | 7.73610342452713e-10 | 239417.53125 | -1.6730367091710718e-11 | -0.007758015766739845 | 1.7455309420100207e-09 | 1.5885858600794833e-11 | 5.4243983165901816e-14 | 1.8682912205150726e-13 | 0 | 2.4765677999239415 | COMPLETED |
| 3 | 0.09999999999999998 | 0.1 | 0.15 | 43622.93359375 | 17779.8828125 | 1.7690912623713473e-10 | -2.1480643652704856e-10 | 7.978592231339121e-10 | 238118.140625 | 0.0007609655149281025 | -0.007743631023913622 | 1.7455995537929425e-09 | 1.5884561027634803e-11 | 5.629040460207284e-14 | -2.8314314477029257e-05 | 0 | 3.4698342999909073 | COMPLETED |
