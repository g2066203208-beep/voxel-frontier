# C3 Simpack–Abaqus interface closure

The CSE/native AeroDyn branches are not used. The closed route is the self-developed `WT-MBD-FE-1` persistent bridge:

`Simpack RNA ↔ six-component interface record ↔ Abaqus UAMP tower endpoint`

The isolated run `WT_MBD_FE_SINGLE_0p15/run14` completed three macro exchanges (0.05, 0.10, 0.15 s). Simpack continuation returned code 0 for all three steps; Abaqus 2025 linked and loaded UAMP, produced an ODB, and completed the dynamic step. The exchange table records the six force/moment components and the corresponding reaction at each exchange.

This short run is the interface-closure test. It is not presented as a 600 s production response. Native CSE and native Simpack AeroDyn remain outside the selected route.
