# R3-A 孤立 DTU 10 MW 柔性叶片模态验证

## 目的

按 Sayed et al. (2019) 的验证顺序，先验证单片柔性叶片结构，再进入 AeroDyn 或长时间耦合。我们的柔性体来源仍为 Abaqus→FBI，不改写为 Sayed 的 50 个参数化 Timoshenko 梁单元。

## 实际执行

- 输入副本：`single_blade_vv_r2_20260904/DTU158_R1_Blade1_FLEX_R18_Z28.spck`
- 输出副本：`R3A_isolated_blade_modal/DTU158_R1_Blade1_ISOLATED_MODAL_R3A_v2.spck`
- 目标柔性体：`$B_Blade1`，Simpack body type 1
- 根接口：`$M_Blade1_FENode_R12`，FBI retained node `101396`
- 接口局部坐标：`(0, 0, 2.8 m)`
- 根连接：`$J_Pitch1`，固定边界
- 外力：Aero6DOF、三组变桨阻尼、转子轴承力均禁用
- 其余刚体：仅在验证副本中降为数值隔离质量/惯量；原输入副本和母版未修改

## Solver 实证

Simpack 2021-build101 `eigenvalues` 返回码 0，使用 1 个线程，生成真实结果：

`C:/Users/tt/Documents/Codex/simpack-mcp-runs/R3A_ISOLATED_BLADE_MODAL_V2_20260904/DTU158_R1_Blade1_ISOLATED_MODAL_R3A_v2.ev.sbr`

六个 IRM 频率为 0.639541、1.128693、2.077099、3.743888、5.886648、8.629333 Hz。FBI 元数据、接口节点和求解器日志均可追溯。

## 门禁结论

| 项目 | 状态 |
|---|---|
| 孤立副本生成 | PASS |
| 根接口身份与坐标 | PASS |
| 外力关闭 | PASS |
| Simpack 特征值求解 | PASS |
| 与 Abaqus 频率的数值记录 | PASS |
| flap/edge 物理振型识别 | OPEN |
| 论文级物理模态 V&V | NOT_YET_PASS |
| AeroDyn | BLOCKED_BY_MODAL_GATE |

注意：当前 Simpack Post 导出的 `eigenmodes` 结果包含 IRM 广义模态及能量通道，但没有足够的物理节点位移分量来可靠区分 1F/1E/2F/2E/3F。因此不能把频率序号直接冒充 flap/edge 对应，也不能宣称 R3-A 已通过。

## 下一步

需要补充同一边界条件下的物理振型输出（或从 FBI/Abaqus 提取节点振型并计算 MAC），完成 1F、1E、2F、2E、3F 的对应后，才能开放 AeroDyn；随后再按 Guma et al. (2021) 做重力/离心刚化验证。
