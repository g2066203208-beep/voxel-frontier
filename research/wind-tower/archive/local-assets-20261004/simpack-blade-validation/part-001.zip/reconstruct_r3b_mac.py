import csv, json, re
from pathlib import Path
import numpy as np

BASE = Path(r"C:\Users\tt\Documents\Codex\simpack-mcp-runs\taskbook_flex_vv_20260904")
SUPER = BASE / "SIMPACK_FBI_SUPER_DUMP_R3B.txt"
REC = BASE / "SIMPACK_FBI_RECOVERY_DUMP_R3B.txt"
COORD = BASE / "ABAQUS_NODE_COORDS_R3B.csv"
ABAQ = BASE / "ABAQUS_MODAL_SHAPES_R3B.csv"
OUT = BASE / "FBI_BASIS_RECONSTRUCTION_R3B.csv"
MACOUT = BASE / "FBI_BASIS_CANDIDATE_MAC_R3B.csv"
AUDIT = BASE / "SIMPACK_MODAL_RECONSTRUCTION_AUDIT_R3B.json"

num = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eEdD][-+]?\d+)?"
matline = re.compile(r"^\s*(\d+)\s+(\d+)\s+(" + num + r")\s*$")
rechead = re.compile(r"columns\s+(\d+)\s+to\s+(\d+)", re.I)
recline = re.compile(r"^\s*(\d+)\s+([1-3])\s+(.*)$")

def f(x):
    return float(x.replace("D", "E").replace("d", "e"))

def read_matrix(path, title, end_title):
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    a = next(i for i, s in enumerate(lines) if s.strip().lower() == title)
    b = next(i for i in range(a + 1, len(lines)) if lines[i].strip().lower() == end_title)
    m = np.zeros((20, 20), float)
    for s in lines[a:b]:
        q = matline.match(s)
        if q:
            m[int(q.group(1)) - 1, int(q.group(2)) - 1] = f(q.group(3))
    return m

M = read_matrix(SUPER, "mass matrix", "end of mass matrix")
K = read_matrix(SUPER, "stiffness matrix", "end of stiffness matrix")
Mff, Kff = M[6:, 6:], K[6:, 6:]
A = np.linalg.solve(Mff, Kff)
lam, vec = np.linalg.eig(A)
order = np.argsort(np.real(lam))
lam = np.real(lam[order]); vec = np.real(vec[:, order])
freq = np.sqrt(np.maximum(lam, 0.0)) / (2.0 * np.pi)
q_modes = []
for j in range(len(freq)):
    qf = vec[:, j]
    den = float(qf.T.dot(Mff).dot(qf))
    qf = qf / np.sqrt(abs(den))
    q = np.zeros(20); q[6:] = qf
    q_modes.append(q)

coords = {}
with COORD.open(newline="") as g:
    for row in csv.DictReader(g):
        coords[int(row["node_id"])] = (float(row["x"]), float(row["y"]), float(row["z"]))

rec = {}
block = None
for s in REC.read_text(encoding="utf-8", errors="replace").splitlines():
    h = rechead.search(s)
    if h:
        block = int(h.group(1))
        continue
    q = recline.match(s)
    if not q or block is None:
        continue
    if block not in (1, 7, 13, 19):
        continue
    # simpack-flx dump can occasionally concatenate two records on one
    # physical line.  Parse the first record and any following complete
    # records using the block's declared column count.
    ncol = 2 if block == 19 else 6
    toks = q.group(3).split()
    records = [(int(q.group(1)), int(q.group(2)), toks[:ncol])]
    rest = toks[ncol:]
    while rest:
        if len(rest) < 2 + ncol:
            # Ignore an incomplete tail rather than corrupting a matrix row.
            break
        try:
            nid2, dof2 = int(rest[0]), int(rest[1])
            vals2 = rest[2:2+ncol]
            if dof2 not in (1, 2, 3):
                break
            records.append((nid2, dof2, vals2))
            rest = rest[2+ncol:]
        except ValueError:
            break
    for nid, dof, rawvals in records:
        if len(rawvals) != ncol:
            continue
        vals = [f(x) for x in rawvals]
        a = rec.setdefault((nid, dof), np.zeros(20))
        a[block - 1:block - 1 + ncol] = vals

rs = [0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 1.00]
z0, z1 = 2.8, 89.166
station_nodes = []
for r in rs:
    zt = z0 + r * (z1 - z0)
    zplane = min(abs(c[2] - zt) for c in coords.values())
    zplane_val = min(c[2] for c in coords.values() if abs(abs(c[2] - zt) - zplane) < 1e-8)
    ids = [nid for nid, c in coords.items() if abs(c[2] - zplane_val) < 1e-6]
    station_nodes.append((r, zt, zplane_val, ids))

shapes = []
for mi, q in enumerate(q_modes):
    for r, zt, zp, ids in station_nodes:
        vals = []
        for dof in (1, 2, 3):
            vv = [float(rec[(nid, dof)].dot(q)) for nid in ids if (nid, dof) in rec]
            vals.append(sum(vv) / len(vv) if vv else float("nan"))
        shapes.append({"simpack_mode": mi + 1, "simpack_freq_hz": float(freq[mi]), "r_over_R": r, "z_target": zt, "z_plane": zp, "section_nodes": len(ids), "U1_mean": vals[0], "U2_mean": vals[1], "U3_mean": vals[2]})

with OUT.open("w", newline="") as g:
    w = csv.DictWriter(g, fieldnames=list(shapes[0].keys())); w.writeheader(); w.writerows(shapes)

ab = []
with ABAQ.open(newline="") as g:
    for row in csv.DictReader(g):
        row = {k: float(v) if k not in ("abaqus_mode",) else int(v) for k, v in row.items()}
        ab.append(row)
aba_modes = sorted(set(int(x["abaqus_mode"]) for x in ab))
sim_modes = sorted(set(int(x["simpack_mode"]) for x in shapes))
def vector(rows, keys):
    out = []
    for r in rs:
        row = next(x for x in rows if abs(x["r_over_R"] - r) < 1e-12)
        out.extend(row[k] for k in keys)
    return np.array(out, float)

mac_rows = []
for ai in aba_modes:
    ar = [x for x in ab if int(x["abaqus_mode"]) == ai]
    va = vector(ar, ["U1_mean", "U2_mean", "U3_mean"])
    for si in sim_modes:
        sr = [x for x in shapes if int(x["simpack_mode"]) == si]
        vs = vector(sr, ["U1_mean", "U2_mean", "U3_mean"])
        den = float(va.dot(va) * vs.dot(vs))
        mac = float((va.dot(vs) ** 2) / den) if den > 0 else float("nan")
        sf = float(sr[0]["simpack_freq_hz"])
        af = float(ar[0]["abaqus_mode"])
        mac_rows.append({"abaqus_mode": ai, "abaqus_freq_hz": float(next(x for x in ar if abs(x["r_over_R"]-0.05)<1e-12)["abaqus_mode"]), "fbi_basis_mode": si, "fbi_basis_frequency_hz": sf, "basis_projection_mac_translation": mac, "frequency_difference_hz": sf - af})

# Replace the temporary Abaqus frequency field with the authoritative values from the prior classification table.
afreq = {1:0.610830, 2:0.961390, 3:1.752600, 4:2.876800, 5:3.581800, 6:5.709500}
for row in mac_rows:
    row["abaqus_freq_hz"] = afreq.get(row["abaqus_mode"], float("nan"))
    row["frequency_difference_hz"] = row["fbi_basis_frequency_hz"] - row["abaqus_freq_hz"]
with MACOUT.open("w", newline="") as g:
    w = csv.DictWriter(g, fieldnames=list(mac_rows[0].keys())); w.writeheader(); w.writerows(mac_rows)

best = {}
for ai in aba_modes:
    cand = [x for x in mac_rows if x["abaqus_mode"] == ai]
    best[ai] = max(cand, key=lambda x: x["basis_projection_mac_translation"])
AUDIT.write_text(json.dumps({"status":"COMPLETED_WITH_MAC_GATE_OPEN","recovery_rows":len(rec),"recovery_columns":20,"station_count":len(rs),"raw_fbi_basis_eigenfrequencies_hz":[float(x) for x in freq[:6]],"best_basis_projection_by_abaqus_mode":best,"system_irm_mac_status":"NOT_CLOSED","note":"These are official FBI recovery-basis projections, not Abaqus-vs-Simpack system IRM MACs. Current FBI retains one interface node, so node-level Simpack vectors are unavailable."}, indent=2), encoding="utf-8")
print(json.dumps({"freq":freq[:6].tolist(),"recovery_keys":len(rec),"stations":[len(x[3]) for x in station_nodes],"best":best}, indent=2))
