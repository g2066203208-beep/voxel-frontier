import csv, json, re
from pathlib import Path
import numpy as np

BASE = Path(r"C:\Users\tt\Documents\Codex\simpack-mcp-runs\taskbook_flex_vv_20260904")
SUPER = BASE / "SIMPACK_FBI_SUPER_DUMP_R3B.txt"
REC = BASE / "SIMPACK_FBI_RECOVERY_DUMP_R3B.txt"
COORD = BASE / "ABAQUS_NODE_COORDS_R3B.csv"
ABAQ = BASE / "ABAQUS_MODAL_SHAPES_R3B.csv"
OUT = BASE / "ABAQUS_TO_FBI_PROJECTION_R3B.csv"
AUDIT = BASE / "ABAQUS_TO_FBI_PROJECTION_AUDIT_R3B.json"
num = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eEdD][-+]?\d+)?"
matline = re.compile(r"^\s*(\d+)\s+(\d+)\s+(" + num + r")\s*$")
rechead = re.compile(r"columns\s+(\d+)\s+to\s+(\d+)", re.I)
recline = re.compile(r"^\s*(\d+)\s+([1-3])\s+(.*)$")
def f(x): return float(x.replace("D", "E").replace("d", "e"))
def read_matrix(path, title, end_title):
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    a = next(i for i,s in enumerate(lines) if s.strip().lower()==title)
    b = next(i for i in range(a+1,len(lines)) if lines[i].strip().lower()==end_title)
    m=np.zeros((20,20))
    for s in lines[a:b]:
        q=matline.match(s)
        if q: m[int(q.group(1))-1,int(q.group(2))-1]=f(q.group(3))
    return m
M=read_matrix(SUPER,"mass matrix","end of mass matrix")
K=read_matrix(SUPER,"stiffness matrix","end of stiffness matrix")
coords={}
with COORD.open(newline="") as g:
    for row in csv.DictReader(g): coords[int(row["node_id"])] = (float(row["x"]),float(row["y"]),float(row["z"]))
rec={}; block=None
for s in REC.read_text(encoding="utf-8", errors="replace").splitlines():
    h=rechead.search(s)
    if h: block=int(h.group(1)); continue
    q=recline.match(s)
    if not q or block not in (1,7,13,19): continue
    ncol=2 if block==19 else 6
    toks=q.group(3).split(); records=[(int(q.group(1)),int(q.group(2)),toks[:ncol])]; rest=toks[ncol:]
    while len(rest)>=2+ncol:
        try: nid2,dof2=int(rest[0]),int(rest[1])
        except ValueError: break
        if dof2 not in (1,2,3): break
        records.append((nid2,dof2,rest[2:2+ncol])); rest=rest[2+ncol:]
    for nid,dof,vals in records:
        if len(vals)==ncol:
            a=rec.setdefault((nid,dof),np.zeros(20)); a[block-1:block-1+ncol]=[f(x) for x in vals]
rs=[0.05,0.10,0.20,0.30,0.40,0.50,0.60,0.70,0.80,0.90,1.00]
z0,z1=2.8,89.166; stations=[]
for r in rs:
    zt=z0+r*(z1-z0); zp=min((c[2] for c in coords.values()),key=lambda z:abs(z-zt))
    ids=[nid for nid,c in coords.items() if abs(c[2]-zp)<1e-6]
    # average recovery rows at each station; columns 6: are flexible coordinates
    mat=np.zeros((3,14)); count=np.zeros(3)
    for nid in ids:
        for j,dof in enumerate((1,2,3)):
            if (nid,dof) in rec: mat[j]+=rec[(nid,dof)][6:]; count[j]+=1
    mat/=np.maximum(count[:,None],1)
    stations.append((r,mat))
R=np.vstack([x[1] for x in stations])
ab=[]
with ABAQ.open(newline="") as g:
    for row in csv.DictReader(g): ab.append({k:(int(v) if k=="abaqus_mode" else float(v)) for k,v in row.items()})
afreq={1:0.610830,2:0.961390,3:1.752600,4:2.876800,5:3.581800,6:5.709500}
rows=[]; qout={}
for mi in sorted(set(int(x["abaqus_mode"]) for x in ab)):
    ar=[x for x in ab if int(x["abaqus_mode"])==mi]
    y=np.array([v for r in rs for x in [next(z for z in ar if abs(z["r_over_R"]-r)<1e-12)] for v in (x["U1_mean"],x["U2_mean"],x["U3_mean"])])
    q,resid,rank,s=np.linalg.lstsq(R,y,rcond=None)
    yh=R@q; den=float(y@y*yh@yh); mac=float((y@yh)**2/den) if den>0 else float("nan")
    ray=float(q@K[6:,6:]@q/(q@M[6:,6:]@q)) if q@M[6:,6:]@q>0 else float("nan")
    fr=float(np.sqrt(max(ray,0))/(2*np.pi))
    err=float(np.linalg.norm(y-yh)/max(np.linalg.norm(y),1e-30))
    qout[str(mi)] = q.tolist()
    rows.append({"abaqus_mode":mi,"abaqus_freq_hz":afreq.get(mi,float("nan")),"projection_rank":int(rank),"projection_mac_translation":mac,"relative_reconstruction_error":err,"rayleigh_fbi_freq_hz":fr,"q_norm":float(np.linalg.norm(q))})
with OUT.open("w",newline="") as g:
    w=csv.DictWriter(g,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
AUDIT.write_text(json.dumps({"status":"COMPLETED","station_count":len(rs),"recovery_keys":len(rec),"basis_columns":14,"rows":rows,"q_coordinates_by_abaqus_mode":qout,"note":"Least-squares projection of Abaqus station translations into the official FBI recovery basis. This is a basis/reconstruction audit; it does not replace Simpack Solver IRM eigenvectors."},indent=2),encoding="utf-8")
print(json.dumps({"status":"COMPLETED","rows":rows},indent=2))
