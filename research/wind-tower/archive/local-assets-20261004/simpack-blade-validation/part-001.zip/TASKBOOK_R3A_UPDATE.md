# 任务书 R3-A 更新

## 已完成

1. 采用现有 Abaqus→FBI 官方 DTU 10 MW 叶片副本，不修改母版。
2. 建立 R3-A 孤立叶片模态验证副本。
3. 固定叶片根接口，关闭 AeroDyn/阻尼/轴承外力。
4. 通过 Simpack 官方 Solver 完成特征值求解并生成 `.ev.sbr`。
5. 将 Simpack IRM 频率与 Abaqus fixed-root 频率及 Sayed 参考值登记到 CSV。

## 不得越过的门禁

目前只能说“求解链路通过、数值频率已登记”，不能说“物理模态 V&V 通过”。原因是 1F/1E/2F/2E/3F 尚未通过物理振型或 MAC 对应。AeroDyn、湍流和 600 s 联合仿真保持锁定。

## 依据关系

- Sayed et al. (2019)：孤立叶片频率验证先于 BEM–MBS 气动弹性计算；其 50 个 Timoshenko 梁单元属于其参数化建模路线。
- Guma et al. (2021)：结构验证后再加入重力与离心力，检查旋转状态刚化。
- 本项目新增：Abaqus 原模型→FBI 的质量、惯量、接口和振型等效性验证；这不是冒充 Sayed 原文方法。
