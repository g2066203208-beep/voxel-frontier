# 任务书 R1 门禁结果（实机）

## 结论

当前隔离工作包中的官方 FBI 叶片副本已通过 Simpack 数值 smoke test；物理 V&V 仍未通过，不能接入生产级 AeroDyn 或外部六分量桥。

本轮核对确认：Abaqus `refblade_select2_substructure.dat` 的 7.5759 Hz、15.114 Hz 等数值是自由-自由模型去掉 6 个刚体模态后的弹性模态（Abaqus 模态 7–12）。Simpack R14 固定根结果中的 0.6395–8.6293 Hz 来自 FBI 的接口/约化自由度系统，不能与 Abaqus 模态 7–12 直接一一配对。该结果证明求解链和 FBI 读取成功，但不构成物理频率匹配通过。

| 门禁 | 状态 | 证据 |
|---|---|---|
| Live inventory | PASS | Simpack 2021-build101 MCP SJS inventory |
| Test call | PASS | `flex_modal_slv=1`, `solver=1` |
| 2 s integration | PASS | 19 steps, 0 rejected, return code 0 |
| Static equilibrium | FAIL | nonlinear solver did not converge |
| Eigenvalues | PASS (solver) / NOT_YET_PASS (physical V&V) | R14 exported 6 real channels; interpretation and Abaqus elastic-mode pairing remain unresolved |
| Root/pitch interface | BLOCKED | 100.031 m marker mismatch; joints type 20 |
| AeroDyn coupling | NOT STARTED | prerequisite not met |
| External bridge | NOT STARTED | prerequisite not met |

## 关键文件

- `BLADE_ROOT_INTERFACE_LEDGER.csv`：实际节点、marker、坐标和门禁状态。
- `SINGLE_BLADE_MASS_CG_INERTIA.csv`：DTU/Abaqus 导出的叶片质量、质心和惯量。
- `taskbook_flex_vv_report.json`：MCP 实机运行报告。
- `taskbook_gate_report.json`：本次任务书门禁汇总。
- `SIMPACK_R14_EIGEN_CHANNELS.csv`：由 Simpack Post COM 导出的 R14 模态通道（频率、无阻尼频率、广义质量、广义刚度）。

原始 `.spck`、`.fbi` 和 Abaqus 文件均未覆盖。

## 本轮新增证据

- R15：在隔离副本中测试关节解锁诊断，`testcall_simple` 和 `eigenvalues` 均返回码 0；由于出现额外零频率，未作为 V&V 模型采用。
- R16：替换为另一份 FBI 后检测到 `0 dynamic dof`，因此拒绝采用。
- R18：将接口 Marker 从局部 z=5.6 m 改为 z=2.8 m；Simpack 明确报告节点偏差为 2.8 m，频率未改变，说明该坐标修正不能解释当前低频差异。

结论保持为：`FLEX_SOLVER_SMOKE = PASS`，`FLEX_BLADE_PHYSICAL_VV = NOT_YET_PASS`，`FLEX_AERODYN_COUPLING = NOT_STARTED`，`FLEX_EXTERNAL_BRIDGE = NOT_STARTED`。
