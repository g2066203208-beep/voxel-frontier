# FBI geometry and modal interpretation audit R2

## Scope

This audit uses the installed Simpack `simpack-flx dump --geo/--check` command and the existing Abaqus output. It is read-only and uses the isolated taskbook copies; the DTU master model is not modified.

## Interface identity

The official FBI `DTU_refblade_from_select2.fbi` reports:

- retained nodes: 1;
- retained node: `101396`;
- FE coordinates: `(0, 0, 2.8)` m;
- retained DOFs: 1–6;
- rows 7–20: fourteen generalized flexible coordinates.

The Simpack R18 candidate sets both `$M_Blade1_FE_reference_R2` and `$M_Blade1_FENode_R12` to local `(0, 0, 2.8)` m and connects `$J_Pitch1` to the FE-node marker. This is the relevant FE-interface check. The former R1 ledger value of about 100 m compared the display CAD marker at the blade span with the FE root node and is therefore not a valid interface criterion. The corrected ledger is `BLADE_ROOT_INTERFACE_LEDGER_R2.csv`.

## Modal interpretation

The Abaqus free-interface frequency extraction contains six near-zero rigid modes followed by elastic modes 7–12 at 7.5759, 15.114, 18.626, 32.215, 36.044 and 40.165 Hz. The substructure retains those six rigid-body interface DOFs plus fourteen generalized coordinates.

Simpack R14/R18 eigenvalue output contains six channels labelled `IRM` (interface-reduced modes): 0.639541, 1.128693, 2.077099, 3.743888, 5.886648 and 8.629333 Hz. Post COM confirms that each channel is a genuine flexible strain mode of `$B_Blade1` (`eStrain/fst_001` … `fst_006`), not a failed solve. These are not directly pairable with Abaqus free-interface modes 7–12 by frequency sorting because they are system/interface-reduced modes after the FBI transformation and current Simpack boundary model. The raw FBI matrix has 20 retained rows and its diagonal generalized stiffness values are 16.1398, 50.20596, 145.161, …; these are reduced coordinates, not the Abaqus eigenvalue table.

## Decision

The interface-coordinate gate is corrected to `PASS_FE_INTERFACE` for the single-blade candidate. `FLEX_SOLVER_SMOKE` remains PASS. `FLEX_BLADE_PHYSICAL_VV` remains `NOT_YET_PASS` until a like-for-like modal comparison is produced (same interface condition, same retained-mode basis and explicit mode-shape/energy correspondence). No AeroDyn, three-blade production replication or 600 s coupled run is authorized by this audit.

As a first controlled comparison, an Abaqus fixed-root frequency-only copy was run through the Abaqus MCP. Its first six frequencies are 0.61083, 0.96139, 1.7526, 2.8768, 3.5818 and 5.7095 Hz. The Simpack R14 IRM values are 0.639541, 1.128693, 2.077099, 3.743888, 5.886648 and 8.629333 Hz. The first pair differs by 4.70%; the remaining pairs cannot yet be accepted by frequency sorting because mode type/order correspondence is not established. The detailed table is `MODAL_VV_COMPARISON_R2_FIXEDROOT.csv`.

## Evidence

- FBI: `C:/Users/tt/Documents/Codex/simpack-mcp-runs/dtu-fbi-from-select2-v2/DTU_refblade_from_select2.fbi`
- Abaqus input: `C:/Users/tt/Documents/Codex/simpack-mcp-runs/dtu-abaqus-substructure-run/refblade_substructure_modes_select2.inp`
- Simpack candidate: `C:/Users/tt/Documents/Codex/simpack-mcp-runs/taskbook_flex_vv_20260904/single_blade_vv_r2_20260904/DTU158_R1_Blade1_FLEX_R18_Z28.spck`
- Simpack modal result: `C:/Users/tt/Documents/Codex/simpack-mcp-runs/BLADE1_R14_EIGEN/DTU158_R1_Blade1_FLEX_R14_FIXEDROOT.ev.sbr`
