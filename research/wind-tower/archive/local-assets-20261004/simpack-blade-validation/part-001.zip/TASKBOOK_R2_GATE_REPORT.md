# 任务书 R2 门禁结果（接口判据修正版）

## 结论

R2 修正了 FE 接口坐标判据：官方 FBI 的 `101396` 保留节点和 Simpack FE reference/FENode Marker 均为局部 `(0,0,2.8)` m，接口身份通过。R1 的约 100 m 数值来自显示 CAD 跨度点与 FE 根接口的错误比较，已保留作历史记录，不再作为门禁。

| 门禁 | 状态 | 证据 |
|---|---|---|
| Live inventory | PASS | Simpack 2021-build101 MCP SJS inventory |
| Test call | PASS | `flex_modal_slv=1`, `solver=1` |
| 2 s integration | PASS | 19 steps, 0 rejected, return code 0 |
| FE root/interface identity | PASS | `BLADE_ROOT_INTERFACE_LEDGER_R2.csv`; FBI node 101396 `(0,0,2.8)` m |
| Static equilibrium | FAIL | nonlinear solver did not converge |
| Eigenvalues | PASS (solver) / NOT_YET_PASS (physical V&V) | R14/R18 six real IRM channels; like-for-like Abaqus mode correspondence remains open |
| AeroDyn coupling | NOT_STARTED | physical modal V&V prerequisite not met |
| External bridge | NOT_STARTED | physical modal V&V prerequisite not met |

## 关键解释

Simpack R14/R18 的 0.6395–8.6293 Hz 通道由 Post COM 正式读取，并对应 `$B_Blade1` 的六个 `eStrain/fst_*` flexible modes。它们是 FBI 约化系统的 IRM 输出，不能直接按频率与 Abaqus 自由接口弹性模态 7–12（7.5759–40.165 Hz）排序配对。两者的边界条件/约化坐标必须先统一，才能进行论文级物理 V&V。

## 当前可执行范围

可以继续使用隔离副本进行单片柔性体接口和求解器回归；尚不能把该结果宣称为已经完成的 DTU 物理 V&V，也不能据此启动 AeroDyn 或 600 s 双向耦合生产运行。

原始母版和 R1 报告均未覆盖。

R2 新增 Abaqus MCP fixed-root frequency run (`fixedroot_modes_vv`, COMPLETED). The first six Abaqus values are recorded in `MODAL_VV_COMPARISON_R2_FIXEDROOT.csv`; only the first Simpack/Abaqus pair is within 5%, so the physical modal gate remains open pending mode-shape/type correspondence.

## R2 实机回归证据

对隔离副本 `DTU158_R1_Blade1_FLEX_R18_Z28.spck` 重新执行了 Simpack MCP 官方 Solver：

- `testcall_simple`: return code 0；日志确认 `Node: 101396, dx=0, dy=0, dz=2.8`，并报告 `Using 6 loadcases for interface mode calculation`。
- `integration`: return code 0；1.0 s，170 步，3 次步拒绝，积分器最终成功；生成真实 `.sbr`。
- 通道已由 Simpack Post COM 导出到 `SIMPACK_R18_INTEGRATION_CHANNELS.csv`，包含叶片位移/速度/加速度、FE 接口 Marker 位置及六分量力/矩通道。
