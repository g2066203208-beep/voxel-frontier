# -*- coding: mbcs -*-
#
# Abaqus/CAE Release 2025 replay file
# Internal Version: 2024_09_20-21.00.46 RELr427 198590
# Run by tt on Wed Sep  2 13:54:07 2026
#

# from driverUtils import executeOnCaeGraphicsStartup
# executeOnCaeGraphicsStartup()
#: Executing "onCaeGraphicsStartup()" in the site directory ...
from abaqus import *
from abaqusConstants import *
session.Viewport(name='Viewport: 1', origin=(1.55729, 1.55556), width=229.233, 
    height=154.311)
session.viewports['Viewport: 1'].makeCurrent()
from driverUtils import executeOnCaeStartup
executeOnCaeStartup()
execfile(
    'C:/Users/tt/Documents/Codex/2026-08-30/turbsim/prepare_formal_modal_input.py', 
    __main__.__dict__)
#: The model database "C:\Users\tt\Documents\Codex\2026-08-30\turbsim\outputs\damping_final_20260902\DTU158_HybridTower_v30_LT10K_MODAL_COPY.cae" has been opened.
session.viewports['Viewport: 1'].setValues(displayedObject=None)
#: INPUT_WRITTEN=C:\Users\tt\Documents\Codex\2026-08-30\turbsim\outputs\damping_final_20260902\DTU158_HYBRID_UNDAMPED_MODAL_20260902.inp
print('RT script done')
#: RT script done
