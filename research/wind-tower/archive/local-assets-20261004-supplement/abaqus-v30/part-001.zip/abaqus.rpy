# -*- coding: mbcs -*-
#
# Abaqus/CAE Release 2025 replay file
# Internal Version: 2024_09_20-21.00.46 RELr427 198590
# Run by tt on Tue Aug 18 16:45:12 2026
#

# from driverUtils import executeOnCaeGraphicsStartup
# executeOnCaeGraphicsStartup()
#: Executing "onCaeGraphicsStartup()" in the site directory ...
from abaqus import *
from abaqusConstants import *
session.Viewport(name='Viewport: 1', origin=(1.55729, 1.55556), width=229.233, 
    height=154.311)
session.viewports['Viewport: 1'].makeCurrent()
from driverUtils import executeOnCaeStartup
executeOnCaeStartup()
execfile('correct_ctrl006_in_cae.py', __main__.__dict__)
#: The model database "C:\Thesis_Tower185\DTU\DTU158_HybridTower_v30_LT10K_MODAL.cae" has been opened.
session.viewports['Viewport: 1'].setValues(displayedObject=None)
#: The model database has been saved to "C:\Thesis_Tower185\DTU\DTU158_HybridTower_v30_LT10K_MODAL.cae".
#: UPDATED_MODEL DTU158_DLC13_U24_S06_INTERFACE_DYNAMIC
#: UPDATED_AMPLITUDE AMP_SITE_U18p57_S04_FY_A_N
#: FY_CORRECTION_N 6611920.38
#: FY_FIRST_LAST_N -176709.38 153148.43
#: JOB DTU158_DLC13_U24_S06_INTERFACE_DYNAMIC_CTRL006
print('RT script done')
#: RT script done
