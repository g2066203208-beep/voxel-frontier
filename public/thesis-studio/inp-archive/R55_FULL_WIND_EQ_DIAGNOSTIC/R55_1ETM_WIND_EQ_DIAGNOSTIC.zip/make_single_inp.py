import re,sys
from pathlib import Path
p=Path(sys.argv[1]);s=p.read_bytes()
def expand(m): return (p.parent/m[1].decode().strip()).read_bytes().rstrip()+b'\n'
s=re.sub(rb'(?mi)^\*Include,\s*input=([^\r\n]+)\r?\n',expand,s)
assert not re.search(rb'(?mi)^\*Include,',s)
p.with_name(p.stem+'_SINGLE.inp').write_bytes(s)
